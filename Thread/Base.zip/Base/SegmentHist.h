#ifndef _SEGMENT_HIST_H_
#define _SEGMENT_HIST_H_

#include "TypeDef.h"

// p_nMinNum			��С��ֵ
// p_u32SegmentNum		ÿ������
// p_u32SegmentCount	�ܶ���
_INT SegmentHist_create(const _s32 p_nMinNum, const _u32 p_u32SegmentNum, const _u32 p_u32SegmentCount);

_VOID SegmentHist_destroy(_INT p_hHandle);

_VOID SegmentHist_reset(_INT p_hHandle);

_VOID SegmentHist_push(_INT p_hHandle, _s32 p_s32Num);

_VOID SegmentHist_print(_INT p_hHandle, _CHAR *p_szTitle);

const _u32 *SegmentHist_getAll(_INT p_hHandle);

// Ԫ������
_u32 SegmentHist_getCount(_INT p_hHandle);

#endif//_SEGMENT_HIST_H_
