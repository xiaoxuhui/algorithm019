#include "GSG_PIDCtrl.h"
#include "MathGSG.h"
#include "CodeDef.h"
#include <stdlib.h>


_s32 PIDCtrl_calc_base(const PID_CtrlParam_s *p_pstPIDParam, PID_CtrlData_s *p_pstPIDData, _s32 p_s32Dst, _s32 p_s32Src, _s32 p_s32SrcDelta)
{
	const PIDType_e p_ePIDType = p_pstPIDParam->ePIDType;
	if ((p_ePIDType & PIDType_F) != 0){
		p_pstPIDData->s32Ctrl_F = p_s32Dst * p_pstPIDParam->s32Kf / 100;
		if (p_pstPIDParam->s32MaxF != 0){
			MAX_LIMIT(p_pstPIDData->s32Ctrl_F, p_pstPIDParam->s32MaxF);
		}
	}

	_s32 s32Gap = p_s32Dst - p_s32Src;
	if ((p_ePIDType & PIDType_P) != 0){
		p_pstPIDData->s32Ctrl_P = s32Gap * p_pstPIDParam->s32Kp / 100;
		if ((p_ePIDType & PIDType_O) != 0){
			if (p_s32Dst * p_s32Src < 0){
				p_pstPIDData->s32Ctrl_P = (p_s32Dst * p_pstPIDParam->s32Kp - p_s32Src * p_pstPIDParam->s32Ko) / 100;
			}			
		}
		if (p_pstPIDParam->s32MaxP != 0){
			MAX_LIMIT(p_pstPIDData->s32Ctrl_P, p_pstPIDParam->s32MaxP);
		}
	}

	if ((p_ePIDType & PIDType_I) != 0){
		p_pstPIDData->s32Sum_I += s32Gap;
		if (p_pstPIDParam->s32MaxI != 0){
			MAX_LIMIT(p_pstPIDData->s32Sum_I, p_pstPIDParam->s32MaxI);
		}
		p_pstPIDData->s32Ctrl_I = (_s32)(p_pstPIDData->s32Sum_I * p_pstPIDParam->fKi / 100);
	}

	if ((p_ePIDType & PIDType_D) != 0){// ΢�����ֵ��P�ı���
		p_pstPIDData->s32Ctrl_D = p_s32SrcDelta * p_pstPIDParam->s32Kd / 100;
		_s32 s32MaxCtrl_D = abs(p_pstPIDData->s32Ctrl_P * p_pstPIDParam->s32MaxD / 100);
		MAX_LIMIT(p_pstPIDData->s32Ctrl_D, s32MaxCtrl_D);
	}

	p_pstPIDData->s32CtrlExe = p_pstPIDData->s32Ctrl_F + p_pstPIDData->s32Ctrl_P + p_pstPIDData->s32Ctrl_I - p_pstPIDData->s32Ctrl_D;
	if (p_pstPIDParam->s32MaxCtrl != 0){
		MAX_LIMIT(p_pstPIDData->s32CtrlExe, p_pstPIDParam->s32MaxCtrl);
	}
	return p_pstPIDData->s32CtrlExe;
}

_s32 PIDCtrl_calc(const PID_CtrlParam_s *p_pstPIDParam, PID_CtrlData_s *p_pstPIDData, _s32 p_s32Dst, _s32 p_s32Src)
{
	_s32 s32Ctrl_total = PIDCtrl_calc_base(p_pstPIDParam, p_pstPIDData, p_s32Dst, p_s32Src, p_s32Src - p_pstPIDData->s32LastSrc);
	p_pstPIDData->s32LastSrc = p_s32Src;
	p_pstPIDData->s32LastDst = p_s32Dst;
	return s32Ctrl_total;
}

_s32 PIDCtrl_calc_D(const PID_CtrlParam_s *p_pstPIDParam, PID_CtrlData_s *p_pstPIDData, _s32 p_s32Dst, _s32 p_s32Src, _s32 p_s32SrcDelta)
{
	_s32 s32Ctrl_total = PIDCtrl_calc_base(p_pstPIDParam, p_pstPIDData, p_s32Dst, p_s32Src, p_s32SrcDelta);
	p_pstPIDData->s32LastSrc = p_s32Src;
	p_pstPIDData->s32LastDst = p_s32Dst;
	return s32Ctrl_total;
}

_VOID PIDCtrl_reset(PID_CtrlData_s *p_pstPIDData)
{
	memset(p_pstPIDData, 0, sizeof(PID_CtrlData_s));
}
