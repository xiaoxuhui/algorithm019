#include "IDGenerator.h"
#include "SysMemory.h"

typedef struct _IDGInfo_s
{
	_u32 u32MinId;
	_u32 u32MaxId;
	_u32 u32CycleNum;		//	ѭ������
	_u32 u32PID_cur;
}IDGInfo_s;

_INT IDG_create(_u32 p_u32MinId, _u32 p_u32MaxId)
{
	DBG_ASSERT(p_u32MaxId > p_u32MinId);
	IDGInfo_s *pstPIDCache = SYS_MALLOC(sizeof(IDGInfo_s));	
	pstPIDCache->u32MinId = p_u32MinId;
	pstPIDCache->u32MaxId = p_u32MaxId;
	pstPIDCache->u32CycleNum = pstPIDCache->u32MaxId + 1 - pstPIDCache->u32MinId;
	pstPIDCache->u32PID_cur = p_u32MinId;
	return (_INT)pstPIDCache;
}

_u32 IDG_next(_INT p_hHandle)
{
	IDGInfo_s *pstPIDCache = (IDGInfo_s *)p_hHandle;
	_u32 u32CurPid = pstPIDCache->u32PID_cur;
	pstPIDCache->u32PID_cur = (pstPIDCache->u32PID_cur - pstPIDCache->u32MinId + 1) % pstPIDCache->u32CycleNum + pstPIDCache->u32MinId;
	return u32CurPid;
}

_VOID IDG_destroy(_INT p_hHandle)
{
	IDGInfo_s *pstPIDCache = (IDGInfo_s *)p_hHandle;
	SYS_FREE(pstPIDCache);
}
