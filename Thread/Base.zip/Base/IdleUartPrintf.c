#include "IdleUartPrintf.h"
#include "SysPrint.h"
#include "SysTime.h"
#include "CodeDef.h"
#include "TypeDef.h"
#include "Lock.h"
#include "SysConfig.h"
#include "CycleCache.h"

#ifdef PRINT_ON
#ifdef OS_RTOS
#include <stdint.h>
#include <ti/sysbios/knl/Task.h>
#include "MemoryChecker.h"
#endif//OS_RTOS

#define PRINTF_STACK_LEN        256
#define PRINT_BUF_LEN		1024
#define EACH_BUF_LEN		64

typedef struct _UARTPrinter_s
{
	_INT			hCycleCache;
	PrintCallBack	hPrintf;
#ifdef USER_TASK_PRINT
#ifdef OS_RTOS
	_CHAR			szPrintfStack[PRINTF_STACK_LEN];
	Task_Struct		stTaskStructIdle;
#endif//OS_RTOS
#endif // USE_DILE
}UARTPrinter_s;

static UARTPrinter_s *g_pstUARTPrinter = NULL;

static void uartPrintf_flush_impl(_VOID);

#ifdef USER_TASK_PRINT
_VOID taskIdleRun(_u32 arg0, _u32 arg1);
_VOID taskIdleRun(_u32 arg0, _u32 arg1)
{
	while(true)
	{
		TASK_MEMORY_DEFAULT_CHECK(g_pstUARTPrinter->szPrintfStack);
		waitTime(30);
		uartPrintf_flush_impl();  
	}
}
#endif // USER_TASK_PRINT

_BOOL IUP_init(PrintCallBack p_function)
{
	g_pstUARTPrinter = SYS_MALLOC(sizeof(UARTPrinter_s)); 
	DBG_ASSERT(g_pstUARTPrinter != NULL);
	memset(g_pstUARTPrinter, 0, sizeof(UARTPrinter_s)); 

	g_pstUARTPrinter->hCycleCache = CycleCache_create(PRINT_BUF_LEN, true);
	DBG_ASSERT(g_pstUARTPrinter->hCycleCache != 0);

	g_pstUARTPrinter->hPrintf = p_function;	

#ifdef USER_TASK_PRINT
#ifdef OS_RTOS
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = PRINTF_STACK_LEN;
	taskParams.stack = &g_pstUARTPrinter->szPrintfStack;
    taskParams.priority = 1;
	Task_construct(&g_pstUARTPrinter->stTaskStructIdle, taskIdleRun, &taskParams, NULL);
	TASK_MEMORY_INIT(g_pstUARTPrinter->szPrintfStack);
#endif//OS_RTOS
#endif//USER_TASK_PRINT

	return true;
}

_VOID IUP_uninit(_VOID)
{	
}

_VOID IUP_putString(const _CHAR* p_szMsg, const _u16 p_nLen)
{
	CycleCache_push(g_pstUARTPrinter->hCycleCache, p_szMsg, p_nLen);
}

_VOID uartPrintf_flush(_VOID)
{
#ifdef USER_TASK_PRINT
	return;	
#endif

#ifdef MPU_SPI_PRINT
	return;
#endif
	
	uartPrintf_flush_impl();
}

void uartPrintf_flush_impl(_VOID)
{
 	if (NULL == g_pstUARTPrinter->hPrintf){
 		return;
 	}

	_CHAR szMsg[EACH_BUF_LEN] = { 0 };
	_u16 u16TotalLen = 0;
	while (true)
	{
		_u16 nLen = 0;
		IUP_takeString(szMsg, EACH_BUF_LEN - 1, &nLen);
		if (nLen == 0){
			break;
		}
		u16TotalLen += nLen;
		g_pstUARTPrinter->hPrintf(szMsg, nLen);
		if (u16TotalLen >= PRINT_BUF_LEN){
			break;
		}
	}
}

_VOID IUP_takeString(_CHAR* p_szMsg, const _u16 p_BufferLen, _u16* p_nLen)
{
	if(g_pstUARTPrinter == NULL){
		*p_nLen = 0;
		return ;
	}
	_INT nDataLen = CycleCache_pop(g_pstUARTPrinter->hCycleCache, p_szMsg, p_BufferLen);	
	*p_nLen = (_u16)nDataLen;
}

#else
_BOOL IUP_init(PrintCallBack p_function)
{
	return true;
}
_VOID IUP_uninit()
{

}
_VOID IUP_putString(const _CHAR* p_szMsg, const _u16 p_nLen)
{

}

_VOID IUP_takeString(_CHAR* p_szMsg, const _u16 p_BufferLen, _u16* p_nLen)
{
}
_VOID uartPrintf_flush()
{
}
#endif // PRINT_ON
