#ifndef _CYCLE_CACHE_H_
#define _CYCLE_CACHE_H_

#include "TypeDef.h"

_INT CycleCache_create(_u16 p_u16CacheSize, _BOOL p_bNeedLock);

_VOID CycleCache_destroy(_INT p_hHandle);

_BOOL CycleCache_push(_INT p_hHandle, const _CHAR *p_szData, const _u16 p_u16DataLen);

_INT CycleCache_pop(_INT p_hHandle, _CHAR *p_szData, const _u16 p_u16BufferLen);

#endif	//_CYCLE_CACHE_H_


