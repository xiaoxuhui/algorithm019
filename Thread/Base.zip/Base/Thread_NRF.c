#include "Thread.h"
#include "CodeDef.h"
#include <stdio.h>
#include "SysMemory.h"
#include "SysTime.h"



#ifdef OS_NRF



_BOOL createThread(ThreadInfo_s* p_stThreadInfo)
{
	return true;
}

_VOID destroyThread(ThreadInfo_s* p_stThreadInfo)
{
}

//�����߳�
_BOOL startThread(ThreadInfo_s* p_stThreadInfo)
{

	return true;
}


//ֹͣ�ź��߳�
_VOID stopThread(ThreadInfo_s* p_stThreadInfo)
{
}

//�ָ��߳�
_BOOL resumeThread(ThreadInfo_s* p_stThreadInfo)
{
	return true;
}

//�����߳�
_BOOL suspendThread(ThreadInfo_s* p_stThreadInfo)
{
	return true;
}



#endif


