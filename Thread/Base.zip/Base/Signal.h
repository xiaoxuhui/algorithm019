#ifndef _SIGNAL_H_
#define _SIGNAL_H_

#include "TypeDef.h"
#include "Lock.h"

#ifdef WIN32

#elif  defined OS_RTOS

#else
#include <pthread.h>
#define Signal_Thread  pthread_cond_t


//��ʼ���ź�
_VOID initSignal(Signal_Thread* p_pSignal);

//�ȴ��ź�
_VOID waitSignal(Signal_Thread* p_pSignal, Lock_s* p_sLock);

//�����ź�
_VOID resumeSignal(Signal_Thread* p_pSignal);


//ɾ���ź�
_VOID destorySignal(Signal_Thread* p_pSignal);



#endif//win32

#endif//_SIGNAL_H_