#include "ThreadMgr.h"
#include "BaseErrorDef.h"
#include "Lock.h"
#include "CodeDef.h"



static _BOOL	g_bInit = false;

typedef struct _ThreadMgrInnerItem_s
{
	ThreadMgrItem_s	stThreadMgrItem;//�߳���Ϣ
	_BOOL			bUsed;			//�Ƿ�ʹ��
}ThreadMgrInnerItem_s;


typedef struct _ThreadMgr_s
{
	Lock_s					stThreadInfoLock;								    //���߳���Ϣ
	ThreadMgrInnerItem_s	stThreadMgrInnerItemList[EXE_HAVE_THREAD_MAX_COUNT];//�ڲ��̳߳�Ա
	_INT					nRealItemSize;										//ʵ�ʵ��̳߳�Ա��
}ThreadMgr_s;
static ThreadMgr_s* g_pstThreadMgr = NULL;

_BOOL	ThreadMgr_Init()
{
	INIT_STATIC_PARAM(g_pstThreadMgr, ThreadMgr_s, false);
	initLock(&g_pstThreadMgr->stThreadInfoLock);
	g_pstThreadMgr->nRealItemSize = 0;
	memset(g_pstThreadMgr->stThreadMgrInnerItemList, 0, sizeof(ThreadMgrInnerItem_s)*EXE_HAVE_THREAD_MAX_COUNT);
	g_bInit = true;
	return true;
}
_VOID	ThreadMgr_updateLiveTime(const _INT p_nThreadID, const _u64 p_u64LiveTime)
{
	if (!g_bInit)
	{
		return;
	}
	ThreadMgrInnerItem_s*	pstThreadMgrInnerItem = NULL;
	for (_INT nLoop = 0; nLoop < EXE_HAVE_THREAD_MAX_COUNT; nLoop++)
	{
		pstThreadMgrInnerItem = &g_pstThreadMgr->stThreadMgrInnerItemList[nLoop];
		if (pstThreadMgrInnerItem->bUsed)
		{
			if (p_nThreadID == pstThreadMgrInnerItem->stThreadMgrItem.nThreadID)
			{
				pstThreadMgrInnerItem->stThreadMgrItem.u64KeepLiveTime = p_u64LiveTime;
				break;
			}
		}
	}
}
_VOID	ThreadMgr_addItem(const ThreadMgrItem_s* p_stThreadMgrItem)
{
	if (!g_bInit)
	{
		_PRINT_LN_T("AddThread[%s]", p_stThreadMgrItem->szThreadName);
		return ;
	}
	_PRINT_LN("InAddItem!ThreadID=%d", p_stThreadMgrItem->nThreadID);
	lock(&g_pstThreadMgr->stThreadInfoLock);
	ThreadMgrInnerItem_s*	pstThreadMgrInnerItem = NULL;
	for (_INT nLoop = 0; nLoop < EXE_HAVE_THREAD_MAX_COUNT; nLoop++)
	{
		pstThreadMgrInnerItem = &g_pstThreadMgr->stThreadMgrInnerItemList[nLoop];
		if (pstThreadMgrInnerItem->bUsed)
		{
			if (pstThreadMgrInnerItem->stThreadMgrItem.nThreadID == p_stThreadMgrItem->nThreadID)
			{
				pstThreadMgrInnerItem->stThreadMgrItem = *p_stThreadMgrItem;
				break;
			}
			continue;
		}
		pstThreadMgrInnerItem->bUsed = true;
		memcpy(&pstThreadMgrInnerItem->stThreadMgrItem, p_stThreadMgrItem, sizeof(ThreadMgrItem_s));
		//pstThreadMgrInnerItem->stThreadMgrItem = *p_stThreadMgrItem;
		g_pstThreadMgr->nRealItemSize++;
		break;
	}
	unlock(&g_pstThreadMgr->stThreadInfoLock);
}

_VOID	ThreadMgr_getAllItem(ThreadMgrItem_s* p_stThreadMgrItemList, _INT* p_nOutItemSize)
{
	if (!g_bInit)
	{
		return ;
	}
	lock(&g_pstThreadMgr->stThreadInfoLock);
	_INT	nOutItemSize = 0;
	ThreadMgrInnerItem_s*	pstThreadMgrInnerItem = NULL;
	for (_INT nLoop = 0; nLoop < EXE_HAVE_THREAD_MAX_COUNT; nLoop++)
	{
		pstThreadMgrInnerItem = &g_pstThreadMgr->stThreadMgrInnerItemList[nLoop];
		if (!pstThreadMgrInnerItem->bUsed)
		{
			continue;
		}
		memcpy(&p_stThreadMgrItemList[nOutItemSize], &pstThreadMgrInnerItem->stThreadMgrItem, sizeof(ThreadMgrItem_s));
		nOutItemSize++;
	}
	unlock(&g_pstThreadMgr->stThreadInfoLock);
	*p_nOutItemSize = nOutItemSize;
	return ;
}


_VOID	ThreadMgr_removeItem(const _INT p_nItemID)
{
	if (!g_bInit)
	{
		return ;
	}
	lock(&g_pstThreadMgr->stThreadInfoLock);
	ThreadMgrInnerItem_s*	pstThreadMgrInnerItem = NULL;
	for (_INT nLoop = 0; nLoop < g_pstThreadMgr->nRealItemSize;nLoop++)
	{
		pstThreadMgrInnerItem = &g_pstThreadMgr->stThreadMgrInnerItemList[nLoop];
		if (!pstThreadMgrInnerItem->bUsed)
		{
			continue;
		}
		if (pstThreadMgrInnerItem->stThreadMgrItem.nThreadID == p_nItemID)
		{
			pstThreadMgrInnerItem->bUsed = false;
			g_pstThreadMgr->nRealItemSize--;
		}
	}
	unlock(&g_pstThreadMgr->stThreadInfoLock);
}

_VOID	ThreadMgr_unInit()
{
	deleteLock(&g_pstThreadMgr->stThreadInfoLock);
	SYS_FREE(g_pstThreadMgr);
}