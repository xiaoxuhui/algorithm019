#include "SysKeyboard.h"


#ifdef WIN32

#include <conio.h>

_INT isKeyDown(_VOID)
{
	return _kbhit();
}

#elif (defined OS_RTOS || defined OS_LITEOS)

#elif defined OS_NRF
#include <stdio.h>
#include <time.h>

_INT isKeyDown(_VOID)

{
	// TODO

	return 0;
}


#else

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>

/* �ж��Ƿ��а������� */
_INT isKeyDown(_VOID)

{
	struct timeval tv;
	struct termios old_termios, new_termios;
	int error;
	int count = 0;
	tcgetattr(0, &old_termios);
	new_termios = old_termios;
	new_termios.c_lflag &= ~ICANON;
	new_termios.c_lflag &= ~ECHO;
	new_termios.c_cc[VMIN] = 1;
	new_termios.c_cc[VTIME] = 0;
	error = tcsetattr(0, TCSANOW, &new_termios);
	tv.tv_sec = 0;
	tv.tv_usec = 100;
	select(1, NULL, NULL, NULL, &tv);
	error += ioctl(0, FIONREAD, &count);
	error += tcsetattr(0, TCSANOW, &old_termios);
	return error == 0 ? count : -1;
}


#endif


