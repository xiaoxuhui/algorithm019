#include "Lock.h"
#include "CodeDef.h"
#include "EncryKey.h"

ENCRY_KEY_0()

#ifdef WIN32

#include <Windows.h>
//��ʼ����
_VOID initLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);

	HANDLE hMutex = CreateMutex(NULL, FALSE, NULL);
	if (hMutex)
	{
		if (ERROR_ALREADY_EXISTS == GetLastError())
		{
			//_PRINT_("MutexLock ERROR_ALREADY_EXISTS");
			return;
		}
	}

	p_pLock->pHandler = (_VOID*)hMutex;
}

//������
_VOID deleteLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	CHECK_NULL(p_pLock->pHandler);

	ReleaseMutex(p_pLock->pHandler);
	CloseHandle(p_pLock->pHandler);
	p_pLock->pHandler = NULL;
}

//����
_VOID lock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	CHECK_NULL(p_pLock->pHandler);

	WaitForSingleObject(p_pLock->pHandler, INFINITE);

}

//����
_VOID unlock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	CHECK_NULL(p_pLock->pHandler);
	ReleaseMutex(p_pLock->pHandler);
}
#elif defined OS_LINUX_DRIVER
//��ʼ����
_VOID initLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	mutex_init(&p_pLock->devlock);
}
_VOID deleteLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	mutex_destroy(&p_pLock->devlock);
}
_VOID lock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	mutex_lock(&p_pLock->devlock);
}

//����
_VOID unlock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	mutex_unlock(&p_pLock->devlock);
}
#elif  defined OS_NRF
#define MAX_LOCK_TIME 	50		//	
static _CHAR szFileName_Null[] = "NULL";
_u16 g_u16LockNum = 0;
_VOID initLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	p_pLock->szFileName = szFileName_Null;
	p_pLock->u32Line = 0;
	p_pLock->u32BeginTime = 0;
	p_pLock->u32EndTime = 0;
	p_pLock->bIsLocked = false;
}

_VOID deleteLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
}

_VOID GSG_lock(Lock_s* p_pLock,const _CHAR *p_szFileName,const _u32 p_u32Line)
{	
	p_pLock->szFileName = p_szFileName;
	p_pLock->u32Line = p_u32Line;
	p_pLock->u32BeginTime = getUpTime_us();
	p_pLock->bIsLocked = true;
}

_VOID GSG_unlock(Lock_s* p_pLock)
{
	p_pLock->u32EndTime = getUpTime_us();	
	p_pLock->bIsLocked = false;
}

_s32 g_s32LockTime_max = 0;
_VOID GSG_lock_check(Lock_s* p_pLock)
{
	_s32 s32DeltaTime = p_pLock->u32EndTime - p_pLock->u32BeginTime;	
	_s32 s32LockTime_max = MAX_NUM(g_s32LockTime_max,s32DeltaTime);
	if(s32LockTime_max != g_s32LockTime_max && s32LockTime_max > MAX_LOCK_TIME){
		_PRINT_LN_T("!!!!!!lock(%s_%u) maxTime: %u us",p_pLock->szFileName,p_pLock->u32Line,s32DeltaTime);
	}	
	g_s32LockTime_max = s32LockTime_max;
}
#else	//linux

//��ʼ����
_VOID initLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	pthread_mutex_init( &p_pLock->mutex, NULL );  
}

//������
_VOID deleteLock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	pthread_mutex_destroy(&p_pLock->mutex);
}

//����
_VOID lock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	pthread_mutex_lock(&p_pLock->mutex);
}

//����
_VOID unlock(Lock_s* p_pLock)
{
	CHECK_NULL(p_pLock);
	pthread_mutex_unlock(&p_pLock->mutex);
}


#endif
