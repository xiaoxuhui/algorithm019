#include "CMD_CreateTool.h"
#include "NetFuncDef.h"


_VOID ICC_addU32(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _u32 p_u32Num)
{
	_u32 nTemp_u32 = htonl(p_u32Num);
	_u8 nSize = sizeof(_u32);
	*pnDataLen += nSize;
	CHECK_BUFFER_SIZE(*pnDataLen, nBufferLen);
	memcpy(*pTempPos, &nTemp_u32, nSize);
	*pTempPos += nSize;
}

_VOID ICC_addU16(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _u16 p_u16Num)
{
	_u16 nTemp_u16 = htons(p_u16Num);
	_u8 nSize = sizeof(_u16);
	*pnDataLen += nSize;
	CHECK_BUFFER_SIZE(*pnDataLen, nBufferLen);
	memcpy(*pTempPos, &nTemp_u16, nSize);
	*pTempPos += nSize;
}

_VOID ICC_addU8(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _u8 p_u8Num)
{
	_u8 nTemp_u8 = p_u8Num;
	_u8 nSize = sizeof(_u8);
	*pnDataLen += nSize;
	CHECK_BUFFER_SIZE(*pnDataLen, nBufferLen);
	memcpy(*pTempPos, &nTemp_u8, nSize);
	*pTempPos += nSize;
}

_VOID ICC_addFloat(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _FLOAT p_fNum)
{
	_u32* u32Tmp = (_u32*)&p_fNum;
	_u32 nTemp_u32 = htonl(*u32Tmp);
	_u8 nSize = sizeof(_u32);
	*pnDataLen += nSize;
	CHECK_BUFFER_SIZE(*pnDataLen, nBufferLen);
	memcpy(*pTempPos, &nTemp_u32, nSize);
	*pTempPos += nSize;
}

_VOID ICC_addCharArray(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _CHAR *p_szData, const _u16 p_nDataLen)
{
	_CHAR* pszPoint = (_CHAR*)p_szData;
	_u16 nSize = p_nDataLen;
	*pnDataLen += nSize;
	CHECK_BUFFER_SIZE(*pnDataLen, nBufferLen);
	memcpy(*pTempPos, pszPoint, nSize);
	*pTempPos += nSize;
}
