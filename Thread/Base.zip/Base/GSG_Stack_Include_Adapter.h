#ifdef OS_RTOS

#ifndef CC2642XX
#include "GSG_Icall.h"
#include "GSG_Util.h"
#include "GSG_Hal_flash.h"
#else
#include "icall.h"
#include "util.h"
#include "hal_flash.h"
#include "hal_board_cfg.h"
#endif




#endif  /*OS_RTOS*/


