#ifndef _MEMORY_CHECKER_H_
#define _MEMORY_CHECKER_H_

#include "TypeDef.h"


#define MEM_CHECK_ON



#ifdef MEM_CHECK_ON

#define TASK_STACK_DEFAULT_VALUE 0xBE
#define TASK_STACK_CHECK_LEN 0x04

_VOID Memory_Init(_u8* p_pPointer, _u8 p_Value, _u8 p_len);
_VOID Memory_Check(const _CHAR *p_szFileName, _u8* p_pPointer, _u8 p_Value, _u8 p_len);

#define MEMORY_CHECK(pointer,value,len) Memory_Check(__FILE__, pointer, value, len)

#define TASK_MEMORY_INIT(pointer) Memory_Init(pointer, TASK_STACK_DEFAULT_VALUE, TASK_STACK_CHECK_LEN)
#define TASK_MEMORY_DEFAULT_CHECK(pointer) Memory_Check(__FILE__, pointer, TASK_STACK_DEFAULT_VALUE, TASK_STACK_CHECK_LEN)



#else
#define MEMORY_CHECK(pointer,value,len)

#define TASK_MEMORY_INIT(pointer)
#define TASK_MEMORY_DEFAULT_CHECK(pointer)
#endif // MEM_CHECK_ON

#endif	//_MEMORY_CHECKER_H_
