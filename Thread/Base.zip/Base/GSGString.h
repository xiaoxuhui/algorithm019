#ifndef _GSG_STRING_H_
#define _GSG_STRING_H_

#include "TypeDef.h"

_VOID GSG_sprintf(_CHAR *p_szBuffer, const _CHAR *p_szFormat, ...);

_BOOL GSG_isHexString(const _CHAR *p_szHexString);

_BOOL GSG_isHexChar(const _CHAR p_cHex);
#endif	//_GSG_STRING_H_

