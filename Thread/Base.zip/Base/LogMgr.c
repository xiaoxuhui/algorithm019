#include "LogMgr.h"
#include "BaseErrorDef.h"
#include "CodeDef.h"
#include "Thread.h"
#include "BaseFile.h"
#include "CycleCache.h"
#include <math.h>
#define LOGFILE_VERSION_LEN			8
#define LOGFILE_DATA_INDEX_LEN		28
#define LOGFILE_INDEXLEN			(28 - 8)
#define LOGFILE_CACHE_BUF_LEN		60*1024	//60k��С

#define LOGFILE_VERSION_1_0			1
#define LOGFILE_EACH_BUFLEN			4*1024



typedef struct _LogFileVersion_s
{
	_u8			u8FileVersion;//�ļ��汾
	_u8			u8RevData[3];//Ԥ������3���ֽ�
	_u32		u32FileLimitLen;//�ļ����ƴ�С
}LogFileVersion_s;

typedef struct _LogFileIndex_s
{
	_u32		nFilePos;//д���ļ������ݽ���
	_u32		nCheckSum;//У���
	_u32		nLastFilePos;//��һ��д���ļ���λ��
	_u32		nLastCheckSum;//��һ�ε�У���
	_u32		u32LastWriteFileTime;//���һ�θ����ļ���ʱ��
}LogFileIndex_s;


typedef struct _LogMgrInner_s
{
	_u8					u8DescripID;//����ID
	File_s				stFile;//�ļ����
	_BOOL				bFileOpen;//�ļ��Ƿ��
	LogFileVersion_s	stLogFileVersion;//��־�ļ��汾
	LogFileIndex_s		stLogFileIndex;//��־�ļ�
	_INT				nBeginFilePos;//��ʼд�����ݵ��ļ�λ��
	_u32				u32LogFileIndexCheckSum;//��־�ļ�����У���
	_INT				nMaxFileSize;//����ļ���С
	_u32				u32FileIndexCheckSum;//�ļ��������У���
	_INT				hCycleCache;//����
	_CHAR				szFileName[FILENAME_MAX_LEN];//�ļ���
}LogMgrInner_s;

typedef struct _LogMgr_s
{
	LogMgrInner_s		stLogMgrInnerList[LOGMGR_INIT_MAX_FILE_SIZE];
	_INT				nListSize;
	ThreadInfo_s		stThreadInfo;//�߳���Ϣ
	_INT				nWriteInterval;//д��־��Flash�ļ��ʱ��
	_u32				u32LastWriteFileTime;//��һ��д���ļ�ʱ��
}LogMgr_s;
static LogMgr_s* g_pstLogMgr = NULL;



_VOID   LogMgr_parseVerAndIndex(const _CHAR* p_szIndexData, LogFileVersion_s* p_stLogFileVersion, LogFileIndex_s* p_stLogFileIndex)
{
	_INT	nDataPos = 0;
	p_stLogFileVersion->u8FileVersion = *(p_szIndexData + nDataPos);
	nDataPos += 1;
	memcpy(p_stLogFileVersion->u8RevData, p_szIndexData + nDataPos, 3);
	nDataPos += 3;
	memcpy(&p_stLogFileVersion->u32FileLimitLen, p_szIndexData + nDataPos, sizeof(_u32));
	nDataPos += 4;
	memcpy(&p_stLogFileIndex->nFilePos, p_szIndexData + nDataPos, sizeof(_u32));
	nDataPos += 4;
	memcpy(&p_stLogFileIndex->nCheckSum, p_szIndexData + nDataPos, sizeof(_u32));
	nDataPos += 4;
	memcpy(&p_stLogFileIndex->nLastFilePos, p_szIndexData + nDataPos, sizeof(_u32));
	nDataPos += 4;
	memcpy(&p_stLogFileIndex->nLastCheckSum, p_szIndexData + nDataPos, sizeof(_u32));
	nDataPos += 4;
	memcpy(&p_stLogFileIndex->u32LastWriteFileTime, p_szIndexData + nDataPos, sizeof(_u32));
}

_VOID   LogMgr_creatVerAndIndex(const LogFileVersion_s* p_stLogFileVersion, const LogFileIndex_s* p_stLogFileIndex,
								_CHAR* p_szIndexData, _INT* p_nDataLen)
{
	_INT	nDataPos = 0;
	*(p_szIndexData + nDataPos) = p_stLogFileVersion->u8FileVersion;
	nDataPos += 1;
	memcpy(p_szIndexData + nDataPos,p_stLogFileVersion->u8RevData, 3);
	nDataPos += 3;
	memcpy(p_szIndexData + nDataPos,&p_stLogFileVersion->u32FileLimitLen, sizeof(_u32));
	nDataPos += 4;
	memcpy(p_szIndexData + nDataPos,&p_stLogFileIndex->nFilePos, sizeof(_u32));
	nDataPos += 4;
	memcpy(p_szIndexData + nDataPos,&p_stLogFileIndex->nCheckSum, sizeof(_u32));
	nDataPos += 4;
	memcpy(p_szIndexData + nDataPos,&p_stLogFileIndex->nLastFilePos, sizeof(_u32));
	nDataPos += 4;
	memcpy(p_szIndexData + nDataPos,&p_stLogFileIndex->nLastCheckSum, sizeof(_u32));
	nDataPos += 4;
	memcpy(p_szIndexData + nDataPos,&p_stLogFileIndex->u32LastWriteFileTime, sizeof(_u32));
	nDataPos += 4;
	*p_nDataLen = nDataPos;
}
_u32    LogMgr_calcFileIndexCheckSum(const LogFileVersion_s* p_stLogFileVersion)
{
	_u32	u32FileVerCheckSum = p_stLogFileVersion->u8FileVersion;
	for (_u8 u8Loop = 0; u8Loop < 3; u8Loop++)
	{
		u32FileVerCheckSum += p_stLogFileVersion->u8RevData[u8Loop];
	}
	_u8	szTemp[4] = { 0 };
	memcpy(szTemp, &p_stLogFileVersion->u32FileLimitLen, sizeof(_u32));
	for (_u8 u8Loop = 0; u8Loop < 4; u8Loop++)
	{
		u32FileVerCheckSum += szTemp[u8Loop];
	}
	return u32FileVerCheckSum;
}
_BOOL   LogMgr_isValidVersionAndIndex(LogFileVersion_s* p_stLogFileVersion, LogFileIndex_s* p_stLogFileIndex,_INT* p_nBeginPos)
{
	if (p_stLogFileVersion->u8FileVersion != LOGFILE_VERSION_1_0)
	{
		return  false;
	}

	_u32	u32FileVerCheckSum = LogMgr_calcFileIndexCheckSum(p_stLogFileVersion);
	_u32	u32FirstCheckSum = u32FileVerCheckSum;
	_u8		szTemp[4] = { 0 };
	memcpy(szTemp, &p_stLogFileIndex->nFilePos, sizeof(_u32));
	for (_u8 u8Loop = 0; u8Loop < 4; u8Loop++)
	{
		u32FirstCheckSum += szTemp[u8Loop];
	}
	if (u32FirstCheckSum == p_stLogFileIndex->nCheckSum)
	{
		*p_nBeginPos = p_stLogFileIndex->nFilePos;
		return true;
	}
	_u32	u32SecondCheckSum = u32FileVerCheckSum;
	memcpy(szTemp, &p_stLogFileIndex->nLastFilePos, sizeof(_u32));
	for (_u8 u8Loop = 0; u8Loop < 4; u8Loop++)
	{
		u32SecondCheckSum += szTemp[u8Loop];
	}
	if (u32SecondCheckSum == p_stLogFileIndex->nLastCheckSum)
	{
		*p_nBeginPos = p_stLogFileIndex->nLastFilePos;
		return true;
	}
	return false;
}

_VOID   LogMgr_creatDefalutVersionAndIndex(const _u32 p_u32FileMaxLen, LogFileVersion_s* p_stLogFileVersion, LogFileIndex_s* p_stLogFileIndex)
{
	p_stLogFileVersion->u8FileVersion = LOGFILE_VERSION_1_0;
	p_stLogFileVersion->u8RevData[0] = 0x11;
	p_stLogFileVersion->u8RevData[1] = 0x22;
	p_stLogFileVersion->u8RevData[2] = 0x33;
	p_stLogFileVersion->u32FileLimitLen = p_u32FileMaxLen;

	_u32	u32FileVerCheckSum = LogMgr_calcFileIndexCheckSum(p_stLogFileVersion);
	p_stLogFileIndex->nFilePos = LOGFILE_DATA_INDEX_LEN;
	_u32	u32FirstCheckSum = u32FileVerCheckSum;
	_u8		szTemp[4] = { 0 };
	memcpy(szTemp, &p_stLogFileIndex->nFilePos, sizeof(_u32));
	for (_u8 u8Loop = 0; u8Loop < 4; u8Loop++)
	{
		u32FirstCheckSum += szTemp[u8Loop];
	}
	p_stLogFileIndex->nCheckSum = u32FirstCheckSum;

	_u32	u32SecondCheckSum = u32FileVerCheckSum;
	p_stLogFileIndex->nLastFilePos = 0;
	memcpy(szTemp, &p_stLogFileIndex->nLastFilePos, sizeof(_u32));
	for (_u8 u8Loop = 0; u8Loop < 4; u8Loop++)
	{
		u32SecondCheckSum += szTemp[u8Loop];
	}
	p_stLogFileIndex->nLastCheckSum = u32SecondCheckSum;
	p_stLogFileIndex->u32LastWriteFileTime = getCurSysTime_ms();
}

_INT	LogMgr_parseAndUpdateIndex(const File_s* p_stFile,const _u32 p_u32FileMaxLen,
								   LogFileVersion_s* p_stLogFileVersion, 
								   LogFileIndex_s* p_stLogFileIndex,_INT* p_nBeginPos)
{


	_BOOL	bRet = seekFile(p_stFile, 0);
	CHECK_ET_VALUE_PRINT_E("SeekFileBeginA!", bRet, true, RET_FAIL);
	_CHAR	szIndexData[LOGFILE_DATA_INDEX_LEN] = { 0 };
	_u32	u32OutLen = 0;
	bRet = readFile(p_stFile, szIndexData, LOGFILE_DATA_INDEX_LEN, &u32OutLen);
	CHECK_ET_VALUE_PRINT_E("ReadIndexData", bRet, true, RET_FAIL);
	LogMgr_parseVerAndIndex(szIndexData, p_stLogFileVersion, p_stLogFileIndex);
	if (!LogMgr_isValidVersionAndIndex(p_stLogFileVersion, p_stLogFileIndex, p_nBeginPos))
	{
		LogMgr_creatDefalutVersionAndIndex(p_u32FileMaxLen, p_stLogFileVersion, p_stLogFileIndex);
		_INT nDataLen = 0;
		LogMgr_creatVerAndIndex(p_stLogFileVersion, p_stLogFileIndex, szIndexData, &nDataLen);
		bRet = seekFile(p_stFile, 0);
		CHECK_ET_VALUE_PRINT_E("SeekFileBeginB!", bRet, true, RET_FAIL);
		bRet = writeFile(p_stFile, szIndexData, nDataLen);
		CHECK_ET_VALUE_PRINT_E("writeFile!", bRet, true, RET_FAIL);
		*p_nBeginPos = LOGFILE_DATA_INDEX_LEN;
	}
	return RET_SUCCESS;
}

_BOOL	LogMgr_InitFile(const LogMgrInitFile_s* p_stLogMgrInitFile, LogMgrInner_s* p_stLogMgrInner)
{
	//���ȴ��ļ�����������ļ�ʧ�ܵĻ�,���������쳣,��Ҫ�Ų�
	_INT	nRet = openFile(&p_stLogMgrInner->stFile, p_stLogMgrInitFile->szFileName, READ_WRITE);
	if (RET_SUCCESS != nRet)
	{
		_PRINT_LN("OpenFile Fail!FileName=%s,nRet=%d", p_stLogMgrInitFile->szFileName, nRet);
		return false;
	}
	_BOOL	bRet = false;
	//Ȼ��ȡ���ļ���С,����ļ���С���������ƴ�С�����ļ����䵽����С
	_INT	nFileSize = getFileSize(&p_stLogMgrInner->stFile);
	if (p_stLogMgrInitFile->nMaxFileSize * 1024 != nFileSize)
	{
		bRet = seekFile(&p_stLogMgrInner->stFile, 0);
		CHECK_ET_VALUE_PRINT_E("seekFile Begin!", bRet, true, false);
		//���䷽ʽ����0
		char szLoopData[1024] = { 0 };
		for (int nLoop = 0; nLoop < p_stLogMgrInitFile->nMaxFileSize; nLoop++)
		{
			writeFile(&p_stLogMgrInner->stFile, szLoopData, 1024);
		}
		flushFile(&p_stLogMgrInner->stFile);
		nFileSize = getFileSize(&p_stLogMgrInner->stFile);
		DBG_ASSERT(nFileSize == p_stLogMgrInitFile->nMaxFileSize * 1024);
	}
	p_stLogMgrInner->nMaxFileSize = p_stLogMgrInitFile->nMaxFileSize * 1024;
	//��ȡ�ļ��������ֽ���(����ļ�û��������,��Ĭ��������д��)
	nRet = LogMgr_parseAndUpdateIndex(&p_stLogMgrInner->stFile, p_stLogMgrInner->nMaxFileSize,
		&p_stLogMgrInner->stLogFileVersion,
		&p_stLogMgrInner->stLogFileIndex, &p_stLogMgrInner->nBeginFilePos);
	DBG_ASSERT(nRet == RET_SUCCESS);
	p_stLogMgrInner->u32FileIndexCheckSum = LogMgr_calcFileIndexCheckSum(&p_stLogMgrInner->stLogFileVersion);
	p_stLogMgrInner->hCycleCache = CycleCache_create(LOGFILE_CACHE_BUF_LEN, true);
	DBG_ASSERT(p_stLogMgrInner->hCycleCache != 0);
	p_stLogMgrInner->bFileOpen = true;
	memcpy(p_stLogMgrInner->szFileName, p_stLogMgrInitFile->szFileName, FILENAME_MAX_LEN);
	p_stLogMgrInner->u8DescripID = p_stLogMgrInitFile->u8DescripID;
	_PRINT_LN("FileName:%s,Max:%d, BeginPos:%d", p_stLogMgrInner->szFileName, 
		p_stLogMgrInner->nMaxFileSize,
		p_stLogMgrInner->nBeginFilePos);
	return true;
}

_BOOL	LogMgr_Init(const LogMgrInit_s* p_stLogMgrInit)
{
	
	INIT_STATIC_PARAM(g_pstLogMgr, LogMgr_s, false);
	g_pstLogMgr->nWriteInterval = p_stLogMgrInit->nWriteInterval;
	g_pstLogMgr->nListSize = 0;
	_BOOL	bRet = false;
	for (_INT nLoop = 0; nLoop < p_stLogMgrInit->nInitFileSize; nLoop++)
	{
		bRet = LogMgr_InitFile(&p_stLogMgrInit->stLogMgrInitFile[nLoop], g_pstLogMgr->stLogMgrInnerList + g_pstLogMgr->nListSize);
		CHECK_ET_VALUE_PRINT_E("LogMgr_InitFile", bRet, true,false);
		g_pstLogMgr->nListSize++;
	}
	return true;
}

_INT   LogMgr_updateLogFileIndex(LogMgrInner_s* p_stLogMgrInner, const LogFileIndex_s* p_stLogFileIndex)
{
	_CHAR szTemp[LOGFILE_INDEXLEN] = { 0 };
	_INT nDataPos = 0;;
	memcpy(szTemp + nDataPos, &p_stLogFileIndex->nFilePos, sizeof(_u32));
	nDataPos += 4;
	memcpy(szTemp + nDataPos, &p_stLogFileIndex->nCheckSum, sizeof(_u32));
	nDataPos += 4;
	memcpy(szTemp + nDataPos, &p_stLogFileIndex->nLastFilePos, sizeof(_u32));
	nDataPos += 4;
	memcpy(szTemp + nDataPos, &p_stLogFileIndex->nLastCheckSum, sizeof(_u32));
	nDataPos += 4;
	memcpy(szTemp + nDataPos, &p_stLogFileIndex->u32LastWriteFileTime, sizeof(_u32));
	nDataPos += 4;
	_BOOL bRet = seekFile(&p_stLogMgrInner->stFile, LOGFILE_VERSION_LEN);
	CHECK_ET_VALUE_PRINT_E("seekFile FailC!", bRet, true, RET_FAIL);
	bRet = writeFile(&p_stLogMgrInner->stFile, szTemp, nDataPos);
	CHECK_ET_VALUE_PRINT_E("writeFileC", bRet, true, RET_FAIL);
	return RET_SUCCESS;
}

_INT    LogMgr_WriteToInnerFile(LogMgrInner_s* p_stLogMgrInner, const _CHAR* p_szData, const _INT p_nDataLen)
{
	LogFileIndex_s	stLogFileIndex = { 0 };
	//
	_u32	nCurEndPos = 0;
	if (p_stLogMgrInner->nBeginFilePos + p_nDataLen >= p_stLogMgrInner->nMaxFileSize - 1)
	{
		nCurEndPos = (p_stLogMgrInner->nBeginFilePos + p_nDataLen) - (p_stLogMgrInner->nMaxFileSize - 1) + LOGFILE_DATA_INDEX_LEN;
	}
	else
	{
		nCurEndPos = (p_stLogMgrInner->nBeginFilePos + p_nDataLen);
	}
	_u32	nLastPos = p_stLogMgrInner->nBeginFilePos;
	_u32	u32CurCheckSum = p_stLogMgrInner->u32FileIndexCheckSum;
	_u8		szTemp[4] = { 0 };
	memcpy(szTemp, &nCurEndPos, sizeof(_u32));
	for (_u8 u8Loop = 0; u8Loop < 4; u8Loop++)
	{
		u32CurCheckSum += szTemp[u8Loop];
	}
	_u32	u32SecondCheckSum = p_stLogMgrInner->u32FileIndexCheckSum;
	memcpy(szTemp, &nLastPos, sizeof(_u32));
	for (_u8 u8Loop = 0; u8Loop < 4; u8Loop++)
	{
		u32SecondCheckSum += szTemp[u8Loop];
	}
	stLogFileIndex.nFilePos = nCurEndPos;
	stLogFileIndex.nCheckSum = u32CurCheckSum;
	stLogFileIndex.nLastFilePos = nLastPos;
	stLogFileIndex.nLastCheckSum = u32SecondCheckSum;
	stLogFileIndex.u32LastWriteFileTime = getCurSysTime_ms();
	_INT nRet = LogMgr_updateLogFileIndex(p_stLogMgrInner, &stLogFileIndex);
	if (RET_SUCCESS != nRet)
	{
		_PRINT_LN("LogMgr_updateLogFileIndex Fail!nRet=%d", nRet);
		return nRet;
	}
	if (p_stLogMgrInner->nBeginFilePos + p_nDataLen >= p_stLogMgrInner->nMaxFileSize)
	{
		_INT nFirstLen = p_stLogMgrInner->nMaxFileSize - p_stLogMgrInner->nBeginFilePos;
		_INT nSecondLen = p_nDataLen - nFirstLen;
		_BOOL bRet = seekFile(&p_stLogMgrInner->stFile, p_stLogMgrInner->nBeginFilePos);
		CHECK_ET_VALUE_PRINT_E("seekFile FailA!", bRet, true, RET_FAIL);
		bRet = writeFile(&p_stLogMgrInner->stFile, p_szData, nFirstLen);
		CHECK_ET_VALUE_PRINT_E("writeFileA", bRet, true, RET_FAIL);
		p_stLogMgrInner->nBeginFilePos = LOGFILE_DATA_INDEX_LEN;
		bRet = seekFile(&p_stLogMgrInner->stFile, p_stLogMgrInner->nBeginFilePos);
		CHECK_ET_VALUE_PRINT_E("seekFile FailB!", bRet, true, RET_FAIL);
		bRet = writeFile(&p_stLogMgrInner->stFile, p_szData + nFirstLen, nSecondLen);
		CHECK_ET_VALUE_PRINT_E("writeFileB", bRet, true, RET_FAIL);
		flushFile(&p_stLogMgrInner->stFile);
	}
	else
	{
		_BOOL bRet = seekFile(&p_stLogMgrInner->stFile, p_stLogMgrInner->nBeginFilePos);
		CHECK_ET_VALUE_PRINT_E("seekFile FailA!", bRet, true, RET_FAIL);
		bRet = writeFile(&p_stLogMgrInner->stFile, p_szData, p_nDataLen);
		CHECK_ET_VALUE_PRINT_E("writeFile", bRet, true, RET_FAIL);
		flushFile(&p_stLogMgrInner->stFile);
	}
	p_stLogMgrInner->nBeginFilePos = nCurEndPos;
	return RET_SUCCESS;
}


_INT	LogMgr_WriteToFile(const _u8 p_u8DescripID, const _CHAR* p_szData, const _INT p_nDataLen)
{
	LogMgrInner_s* pstLogMgrInner = NULL;
	_INT	nRet = -1;
	for (_INT nLoop = 0; nLoop < g_pstLogMgr->nListSize;nLoop++)
	{
		pstLogMgrInner = g_pstLogMgr->stLogMgrInnerList + nLoop;
		if (p_u8DescripID == pstLogMgrInner->u8DescripID)
		{
			nRet = LogMgr_WriteToInnerFile(pstLogMgrInner, p_szData, p_nDataLen);
			return nRet;
		}
	}
	_PRINT_LN("DescripID Not Find!ID:%d", p_u8DescripID);
	DBG_ASSERT(0);
	return RET_SUCCESS;
}
_BOOL		LogMgr_isTimeToWriteDataToFile(const _u32 p_u32CurT)
{
	if (fabs(p_u32CurT - g_pstLogMgr->u32LastWriteFileTime) >= g_pstLogMgr->nWriteInterval * 1000)
	{
		return true;
	}
	return	false;
}


_VOID  LogMgr_checkFileOpen(_VOID)
{
	LogMgrInner_s* pstLogMgrInner = NULL;
	_INT	nRet = -1;
	for (_INT nLoop = 0; nLoop < g_pstLogMgr->nListSize; nLoop++)
	{
		pstLogMgrInner = g_pstLogMgr->stLogMgrInnerList + nLoop;
		if (!pstLogMgrInner->bFileOpen)
		{
			nRet = openFile(&pstLogMgrInner->stFile, pstLogMgrInner->szFileName, CREATE_WRITE);
			if (RET_SUCCESS != nRet)
			{
				_PRINT_LN("OpenFile Fail!FileName=%s,nRet=%d", pstLogMgrInner->szFileName, nRet);
				break;
			}
			pstLogMgrInner->bFileOpen = true;
		}
	}
	waitTime(1000);
}

_VOID  LogMgr_writeCycleCacheData(_VOID)
{
	LogMgrInner_s* pstLogMgrInner = NULL;
	for (_INT nLoop = 0; nLoop < g_pstLogMgr->nListSize; nLoop++)
	{
		pstLogMgrInner = g_pstLogMgr->stLogMgrInnerList + nLoop;
		{
			_INT nTotalLen = 0;
			_CHAR szMsg[LOGFILE_EACH_BUFLEN] = { 0 };
			while (true)
			{
				_INT nDataLen = CycleCache_pop(pstLogMgrInner->hCycleCache, szMsg, LOGFILE_EACH_BUFLEN);
				if (nDataLen == 0){
					break;
				}
				nTotalLen += nDataLen;
				_INT nRet = LogMgr_WriteToFile(pstLogMgrInner->u8DescripID, szMsg, nDataLen);
				if (RET_SUCCESS != nRet)
				{
					closeFile(&pstLogMgrInner->stFile);
					pstLogMgrInner->bFileOpen = false;
					break;
				}
				if (nTotalLen >= LOGFILE_CACHE_BUF_LEN){
					break;
				}
			}
		}
	}
}


ThreadFuncRet_e LogMgr_Thread_Main(void*arg)
{
	LogMgr_checkFileOpen();
	_u32	u32CurrentT = getCurSysTime_ms();
	if (!LogMgr_isTimeToWriteDataToFile(u32CurrentT))
	{
		waitTime(5000);
		return RET_THREAD_CONTINUE;
	}
	
	LogMgr_writeCycleCacheData();
	g_pstLogMgr->u32LastWriteFileTime = u32CurrentT;
	return RET_THREAD_CONTINUE;
}
_INT	LogMgr_Start(_VOID)
{
	g_pstLogMgr->stThreadInfo.u16ThreadStackSize = GSG_THREAD_DEFAULT_STACK_SIZE;
	g_pstLogMgr->stThreadInfo.FuncBody = LogMgr_Thread_Main;
	g_pstLogMgr->stThreadInfo.eThreadMode = THREAD_NORMAL;
	sprintf(g_pstLogMgr->stThreadInfo.szThreadName, "LogMgr");
	_BOOL bRet = startThread(&g_pstLogMgr->stThreadInfo);
	if (!bRet)
	{
		_PRINT_("startThread IT66121 Fail!\n");
		return -1;
	}
	return RET_SUCCESS;
}


_VOID	LogMgr_WriteLog(const _u8 p_u8DescripID, const _CHAR* p_szLogData, const _INT p_nLen)
{
	LogMgrInner_s* pstLogMgrInner = NULL;
	for (_INT nLoop = 0; nLoop < g_pstLogMgr->nListSize; nLoop++)
	{
		pstLogMgrInner = g_pstLogMgr->stLogMgrInnerList + nLoop;
		if (p_u8DescripID == pstLogMgrInner->u8DescripID)
		{
			CycleCache_push(pstLogMgrInner->hCycleCache, p_szLogData, (_u16)p_nLen);
			return;
		}
	}
	DBG_ASSERT(0);
}

_VOID	LogMgr_Stop(_VOID)
{
	stopThread(&g_pstLogMgr->stThreadInfo);
}


_VOID	LogMgr_unInit(_VOID)
{
	SYS_FREE(g_pstLogMgr);
}



