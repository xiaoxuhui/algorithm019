#ifndef _SYS_KEYBOARD_H_
#define _SYS_KEYBOARD_H_

#include "TypeDef.h"

_INT isKeyDown(_VOID);


#endif	//_SYS_KEYBOARD_H_


