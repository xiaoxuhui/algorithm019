#ifndef _CMD_PARSE_TOOL_
#define _CMD_PARSE_TOOL_
#include "GSG.h"
#include "CodeDef.h"


#define CHECK_BUFFER_SIZE(_DataLen_, _BufferLen_) do \
{\
	if (_DataLen_ > _BufferLen_) { _PRINT_("Datalen[%u] > BufLen[%u] ", _DataLen_,_BufferLen_); DBG_ASSERT(0); }\
} while (0)

#define ICP_COMMAND_BEGIN(_pInputData_, _nBufferLen_)	{\
	_u8* pTempPos = (_u8*)_pInputData_; \
	_UINT nBufferLen = _nBufferLen_; \
	_UINT nOffset = 0; \
	_UINT* pOffset = &nOffset;

#define ICP_COMMAND_BEGIN_1(_pInputData_, _nBufferLen_, _pOffset_)	{\
	_u8* pTempPos = (_u8*)_pInputData_; \
	_UINT nBufferLen = _nBufferLen_; \
	_UINT* pOffset = _pOffset_;

_VOID ICP_popU32(_u8 **pTempPos, _u32 *pOffset, const _u32 nBufferLen, _u32 *p_pu32Num);
#define ICP_POP_U32(_pNum_) ICP_popU32(&pTempPos, pOffset, nBufferLen, _pNum_)

_VOID ICP_popU16(_u8 **pTempPos, _u32 *pOffset, const _u32 nBufferLen, _u16 *p_pu16Num);
#define ICP_POP_U16(_pNum_) ICP_popU16(&pTempPos, pOffset, nBufferLen, _pNum_)

_VOID ICP_popU8(_u8 **pTempPos, _u32 *pOffset, const _u32 nBufferLen, _u8 *p_pu8Num);
#define ICP_POP_U8(_pNum_) ICP_popU8(&(pTempPos), pOffset, nBufferLen, _pNum_)



#define ICP_POP_BYTEPOINT(_DATAPOINT_, _DATALEN_)		{\
	*pOffset += _DATALEN_; \
	CHECK_BUFFER_SIZE(*pOffset, nBufferLen); \
	_DATAPOINT_ = pTempPos; \
	pTempPos += _DATALEN_; \
}

#define ICP_POP_BYTEARR(_DATAPOINT_, _DATALEN_)		{\
	*pOffset += _DATALEN_; \
	CHECK_BUFFER_SIZE(*pOffset, nBufferLen); \
	memcpy(_DATAPOINT_, pTempPos, _DATALEN_); \
	pTempPos += _DATALEN_; \
	}


#define ICP_POP_SUB_FUNC(_FUNC_, ...)  {\
	_UINT nTmpOffset = 0; \
	_FUNC_(pTempPos, nBufferLen - *pOffset, &nTmpOffset, __VA_ARGS__); \
	pTempPos += nTmpOffset; \
	*pOffset += nTmpOffset; \
	}

#define ICP_COMMAND_END			}


#define LOCAL_COMMAND_BEGIN(x,y)	ICP_COMMAND_BEGIN(x,y)
#define LOCAL_COMMAND_BEGIN_2(x,y,z)	ICP_COMMAND_BEGIN_1(x,y,z)
#define LOCAL_DO_U32(x)			ICP_POP_U32(&x)
#define LOCAL_DO_U16(x)			ICP_POP_U16(&x)
#define LOCAL_DO_U8(x)			ICP_POP_U8(&x)
#define LOCAL_DO_ENUM(x)		do{_u8 y = (_u8)x; ICP_POP_U8(&y); x=y;}while(false)
#define LOCAL_DO_FLOAT(x)		do{_u32 y = (_u32)x; ICP_POP_U32(&y); _FLOAT* pfTmp = (_FLOAT*)&y; x = (*pfTmp);}while(false)
#define LOCAL_DO_BOOL(x)		do{_u8 y = (_u8)x; ICP_POP_U8(&y); x=(y==0)?false:true;}while(false)
#define LOCAL_DO_BYTEARR(x,y)	ICP_POP_BYTEARR(x,y)
#define LOCAL_DO_BYTEPOINT(x,y)	ICP_POP_BYTEPOINT(x,y)
#define LOCAL_DO_SUB_FUNC(_FUNC_, ...)	ICP_POP_SUB_FUNC(_FUNC_, __VA_ARGS__)
#define LOCAL_COMMAND_END		ICP_COMMAND_END

#endif//_CMD_PARSE_TOOL_
