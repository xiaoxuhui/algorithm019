#include "Thread.h"
#include "Signal.h"
#include "CodeDef.h"
#include <stdio.h>
#include "SysMemory.h"
#include "SysTime.h"



#ifdef OS_RTOS
#ifdef CC2642XX
#include <ti/posix/iar/pthread.h>
#else
#include <ti/sysbios/posix/pthread.h>
#endif
//#include <ti/sysbios/posix/pthread.h>


#define THREAD_STACKSIZE			512

typedef struct _Thread_Status_RTOS_s
{
	void*	              pHandle; //�߳̾��
	_BOOL				  bStopFlag;//ֹͣ��־
	_BOOL				  bExitFlag;//ʵ���˳����
	_BOOL				  bInFuncFlag;//�����û�������־
	Lock_s				  sLock;//�ź���
    //pthread_attr_t        pAttrs;
	void*				  psReturnP;		

}Thread_Status_RTOS_s;


void* Thread_Main(void*	p_pData)
{
	ThreadInfo_s* pThreadInfo = (ThreadInfo_s*)p_pData;
	CHECK_NULL(pThreadInfo->pHandle, NULL);
	//_PRINT_LN_T("enter thread(%s)",pThreadInfo->szThreadName);

	Thread_Status_RTOS_s* pStatusRTOS = (Thread_Status_RTOS_s*)pThreadInfo->pHandle;
	pStatusRTOS->bInFuncFlag = true;
	ThreadFuncRet_e nRet = RET_THREAD_CONTINUE;
	while (nRet == RET_THREAD_CONTINUE)
	{
		nRet = pThreadInfo->FuncBody(pThreadInfo->pData);
		if (pStatusRTOS->bStopFlag)
		{
			break;
		}
	}
	pStatusRTOS->bExitFlag = true;
	//_PRINT_LN_T("exit thread(%s)",pThreadInfo->szThreadName);
	return NULL;
}

_BOOL createThread(ThreadInfo_s* p_stThreadInfo)
{
	CHECK_NULL(p_stThreadInfo, false);
	p_stThreadInfo->pHandle = (void*)SYS_MALLOC(sizeof(Thread_Status_RTOS_s));
	CHECK_NULL(p_stThreadInfo->pHandle, false);


	return true;
}

_VOID destroyThread(ThreadInfo_s* p_stThreadInfo)
{
	SYS_FREE(p_stThreadInfo->pHandle);
}

//�����߳�
_BOOL startThread(ThreadInfo_s* p_stThreadInfo)
{
	Thread_Status_RTOS_s* pStatusRTOS = (Thread_Status_RTOS_s*)p_stThreadInfo->pHandle;
	pStatusRTOS->bStopFlag = false;
	pStatusRTOS->bExitFlag = false;
	pStatusRTOS->bInFuncFlag = false;
	pthread_t           thread;
	int nRet = pthread_create(&thread, NULL, Thread_Main, (void*)p_stThreadInfo);
	if (nRet != 0) {
		/* pthread_create() failed */
		return false;
	}
	pStatusRTOS->pHandle = thread;
	pthread_detach(pStatusRTOS->pHandle);
	return true;
}


//ֹͣ�ź��߳�
_VOID stopThread(ThreadInfo_s* p_stThreadInfo)
{
	CHECK_NULL(p_stThreadInfo);
	CHECK_NULL(p_stThreadInfo->pHandle);
    _u32  u32CurrentTime = getCurSysTime_ms();
    Thread_Status_RTOS_s* pStatusRTOS = (Thread_Status_RTOS_s*)p_stThreadInfo->pHandle;
	if(!pStatusRTOS->bExitFlag)
	{
		pthread_cancel(pStatusRTOS->pHandle);
	}
    pStatusRTOS->bStopFlag = true;
	while (true)
	{
		if (pStatusRTOS->bExitFlag || getCurSysTime_ms() - u32CurrentTime > 300)
		{
			//_PRINT_("stopThread Free Begin bExitFlag=%d!\n", pStatusRTOS->bExitFlag);
			/*void*  pReturn = NULL;
			pthread_join(pStatusRTOS->pHandle,&pReturn);
			pthread_attr_destroy(&pStatusRTOS->pAttrs);*/
                        
			break;

		}
		waitTime(10);
	}
}

//�ָ��߳�
_BOOL resumeThread(ThreadInfo_s* p_stThreadInfo)
{
	return true;
}

//�����߳�
_BOOL suspendThread(ThreadInfo_s* p_stThreadInfo)
{
	return true;
}



#endif