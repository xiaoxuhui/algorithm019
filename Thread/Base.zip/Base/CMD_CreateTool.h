#ifndef _CMD_CREATE_TOOL_
#define _CMD_CREATE_TOOL_

#include "GSG.h"
#include "CodeDef.h"


#define CHECK_BUFFER_SIZE(_DataLen_, _BufferLen_) do \
{\
if (_DataLen_ > _BufferLen_) { DBG_ASSERT(0); }\
} while (0)


#define ICC_COMMAND_BEGIN(_pOutputData_, _nBufferLen_, _pDataLen_)	{\
	_u8* pTempPos = (_u8*)_pOutputData_; \
	_u16 nBufferLen = _nBufferLen_; \
	_u16* pnDataLen = _pDataLen_;

_VOID ICC_addU32(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _u32 p_u32Num);
#define ICC_ADD_U32(_Num_)	ICC_addU32(&pTempPos, pnDataLen, nBufferLen, _Num_)

_VOID ICC_addU16(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _u16 p_u16Num);
#define ICC_ADD_U16(_Num_)	ICC_addU16(&pTempPos, pnDataLen, nBufferLen, _Num_)

_VOID ICC_addU8(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _u8 p_u8Num);
#define ICC_ADD_U8(_Num_)	ICC_addU8(&pTempPos, pnDataLen, nBufferLen, _Num_)

#define ICC_ADD_ENUM(_Num_)	ICC_addU8(&pTempPos, pnDataLen, nBufferLen, (_u8)_Num_)


_VOID ICC_addFloat(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _FLOAT p_fNum);
#define ICC_ADD_FLOAT(_Num_)	ICC_addFloat(&pTempPos, pnDataLen, nBufferLen, _Num_)

#define ICC_ADD_BOOL(_Num_)	do{_u8 nBoolFlag = _Num_ ? 1 : 0;  ICC_addU8(&pTempPos, pnDataLen, nBufferLen, nBoolFlag);}while(false)

_VOID ICC_addCharArray(_u8 **pTempPos, _u16* pnDataLen, const _u16 nBufferLen, const _CHAR *p_szData, const _u16 p_nDataLen);
#define ICC_ADD_BYTEARR(_DATAPOINT_, _DATALEN)	ICC_addCharArray(&pTempPos, pnDataLen, nBufferLen, (const _CHAR *)_DATAPOINT_, _DATALEN)



#define ICC_ADD_SUB_FUNC(_FUNC_, ...)  {\
	_u16 nTmpLen = 0; \
	_FUNC_(__VA_ARGS__, pTempPos, nBufferLen - *pnDataLen, &nTmpLen); \
	pTempPos += nTmpLen; \
	*pnDataLen += nTmpLen; \
	}


#define ICC_COMMAND_END			}


#define LOCAL_COMMAND_BEGIN(x, y, z)	ICC_COMMAND_BEGIN(x, y, z)
#define LOCAL_DO_U32(x)				ICC_ADD_U32(x)
#define LOCAL_DO_U16(x)				ICC_ADD_U16(x)
#define LOCAL_DO_U8(x)				ICC_ADD_U8(x)
#define LOCAL_DO_ENUM(x)			ICC_ADD_ENUM(x)
#define LOCAL_DO_FLOAT(x)			ICC_ADD_FLOAT(x)
#define LOCAL_DO_BOOL(x)			ICC_ADD_BOOL(x)
#define LOCAL_DO_BYTEARR(x,y)		ICC_ADD_BYTEARR(x, y)
#define LOCAL_DO_SUB_FUNC(_FUNC_, ...)	ICC_ADD_SUB_FUNC(_FUNC_, __VA_ARGS__)
#define LOCAL_COMMAND_END			ICC_COMMAND_END
#endif//_CMD_CREATE_TOOL_
