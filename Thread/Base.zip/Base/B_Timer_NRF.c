#include "B_Timer.h"
#ifdef OS_NRF
#include "BaseErrorDef.h"
#include "CodeDef.h"
#include "SysMemory.h"
#include "SysTime.h"
#include <string.h>
#include <assert.h>
#include "Lock.h"
#include "bsp.h"
#include "app_timer.h"
#include "GSG.h"
#include "ThreadWTD.h"

APP_TIMER_DEF(B_TIMR_ID);

#define InvalidTaskId		0

typedef struct _ITimerTask_s
{
	_BOOL					bIsValid;					// ��Ч��־
	_BOOL					bIsStop;					// �Ƿ�ֹͣ
	_u64					u64NextExeTime;		// �´�ִ��ʱ��
	TimerTask_s		stTask;
}ITimerTask_s;

typedef struct _BTimer_s
{
	_u8				u8WTDId;			//	���Ź�ID
	_u8				u8ValidTaskNum;		//	��Ч������
	_u8				u8MinInterval;		//	��С���
	_u8				u8MaxTaskNum;		//	���������
	ITimerTask_s	*pstTaskList;		//	�����б�

	Lock_s			stLock;
}BTimer_s;

static BTimer_s		*g_pstBTimer = NULL;

static _u32 Timer_getTaskId(_VOID)
{//��Χ��[1,
	static _u32 g_u32TaskId = 1;
	_u32 u32TaskId = g_u32TaskId;
	g_u32TaskId++;
	return u32TaskId;
}

_VOID ITimerTask_reset(ITimerTask_s *pstTask)
{
	pstTask->bIsStop = false;
	pstTask->bIsValid = false;
	pstTask->u64NextExeTime = 0xFFFFFFFFFFFFFFFF;
}

ThreadFuncRet_e Timer_run(_VOID *p_pNULL)
{//
	BTimer_s *pstTimer = g_pstBTimer;
	_u64 u64CurrentTime = getCurSysTime_us();
	for (int i = 0; i < pstTimer->u8MaxTaskNum; i++)
	{
		lock(&g_pstBTimer->stLock);
		ITimerTask_s stTimerTask = pstTimer->pstTaskList[i];
		unlock(&g_pstBTimer->stLock);
		if (!stTimerTask.bIsValid){// ��Ч������
			continue;
		}		
		if(stTimerTask.bIsStop){// �����Ѿ�ִ�����, �Ƴ���ʱ����			
			lock(&g_pstBTimer->stLock);
			ITimerTask_reset(&pstTimer->pstTaskList[i]);
			pstTimer->u8ValidTaskNum--;
			unlock(&g_pstBTimer->stLock);			
			//_PRINT_LN_T("BTimer_remove[%u]: %u",stTimerTask.stTask.u32TaskId, g_pstBTimer->u8ValidTaskNum);
			continue;
		}
		if (u64CurrentTime < stTimerTask.u64NextExeTime){// δ��ִ�������ʱ��
			continue;
		} 
		
		// ����ִ��ʱ��ϳ�������Ҫ��ͬ������Ϊ���Ρ�
		TimerTaskRet_e eRet = stTimerTask.stTask.funTask(stTimerTask.stTask.pData);
		
		lock(&g_pstBTimer->stLock);
		if (eRet == TimerTaskRet_Break){//�Ƴ���ʱ����				
			pstTimer->pstTaskList[i].bIsStop = true;
		}
		else{//�����´�ִ��ʱ��
			pstTimer->pstTaskList[i].u64NextExeTime += stTimerTask.stTask.u32Interval * 1000;
		}		
		unlock(&g_pstBTimer->stLock);
	}
	
	//static _u8 u8ValidTaskNum_last = 0;
	//if(pstTimer->u8ValidTaskNum != u8ValidTaskNum_last){
	//	_PRINT_LN_T("BTimer:%u->%u",u8ValidTaskNum_last,pstTimer->u8ValidTaskNum);
	//	u8ValidTaskNum_last = pstTimer->u8ValidTaskNum;
	//}
	
	return RET_THREAD_CONTINUE;
}

_VOID RCMCU_Timer_callback (void *p_context)
{
	ThreadWTD_run(g_pstBTimer->u8WTDId);
	Timer_run(NULL);
}

_VOID RC_MCU_appTimer_Init(const _u8 _pu8TIME_ms)
{		
		ret_code_t nRet;
		nRet=app_timer_create(&B_TIMR_ID,APP_TIMER_MODE_REPEATED,RCMCU_Timer_callback);
		if(nRet!=0)
		{
			_PRINT_LN_T("timer_create_err_nRet %d",nRet);
		}
		DBG_ASSERT(nRet==0);
		nRet=app_timer_start(B_TIMR_ID,APP_TIMER_TICKS(_pu8TIME_ms),NULL);
		
		if(nRet!=0)
		{
			_PRINT_LN_T("timer_start_err_nRet %d",nRet);
		}
		DBG_ASSERT(nRet==0);	
}

//p_u8MinInterval ��С������ڣ����ؾ��
_BOOL B_Timer_init(const _u8 p_u8MinInterval, const _u8 p_u8MaxTaskNum)
{	
	INIT_STATIC_PARAM(g_pstBTimer, BTimer_s, false);
	initLock(&g_pstBTimer->stLock);

	g_pstBTimer->u8MaxTaskNum = p_u8MaxTaskNum;
	g_pstBTimer->pstTaskList = SYS_MALLOC(sizeof(ITimerTask_s)* p_u8MaxTaskNum);
	CHECK_NULL(g_pstBTimer->pstTaskList, false);
	memset(g_pstBTimer->pstTaskList, 0, sizeof(ITimerTask_s)* p_u8MaxTaskNum);

	g_pstBTimer->u8MinInterval = p_u8MinInterval;
	g_pstBTimer->u8ValidTaskNum = 0;

	RC_MCU_appTimer_Init(p_u8MinInterval);	
	g_pstBTimer->u8WTDId = ThreadWTD_requestWTDId("BTimer");
	ThreadWTD_enable(g_pstBTimer->u8WTDId);
	_PRINT_LN_T("WTD_BTimer:%u",g_pstBTimer->u8WTDId);
	return true;
}

_VOID B_Timer_uninit(_VOID)
{
	BTimer_s *pstTimer = g_pstBTimer;
	SYS_FREE(pstTimer->pstTaskList);
	SYS_FREE(pstTimer);	
	app_timer_stop(B_TIMR_ID);
}

//����һ����ʱ����
_INT B_Timer_addTask(TimerTask_s *p_pstTask)
{
	CHECK_NULL(p_pstTask, RET_PARAM_ERROR);
	
	_u64 u64CurrentTime = getCurSysTime_us();
	
	BTimer_s *pstTimer = g_pstBTimer;
	if (pstTimer->u8ValidTaskNum >= pstTimer->u8MaxTaskNum){
		_PRINT_LN_T("B_Timer_addTask failed:%u",pstTimer->u8MaxTaskNum);
		return RET_OVER_MAX_LIMIT;
	}

	ITimerTask_s *pstTask = NULL;
	_INT nRet = RET_OVER_MAX_LIMIT;
	for (int i = 0; i < pstTimer->u8MaxTaskNum; i++)
	{
		pstTask = pstTimer->pstTaskList + i;
		if (pstTask->bIsValid){// 
			continue;
		}
		
		lock(&g_pstBTimer->stLock);
		pstTask->stTask.u32FirstTime = p_pstTask->u32FirstTime;
		pstTask->stTask.u32Interval= p_pstTask->u32Interval;
		pstTask->stTask.pData = p_pstTask->pData;
		pstTask->stTask.funTask = p_pstTask->funTask;		
		pstTask->stTask.u32TaskId = Timer_getTaskId();
		pstTask->u64NextExeTime = u64CurrentTime + p_pstTask->u32FirstTime * 1000;
		p_pstTask->u32TaskId = pstTask->stTask.u32TaskId;
		pstTask->bIsValid = true;
		pstTimer->u8ValidTaskNum++;
		unlock(&g_pstBTimer->stLock);
		
		nRet = RET_SUCCESS;
		break;
	}	
	DBG_ASSERT(nRet == RET_SUCCESS);	
	
	//_PRINT_LN_T("BTimer_add[%u]: %u",pstTask->stTask.u32TaskId, g_pstBTimer->u8ValidTaskNum);
	return nRet;
}

ITimerTask_s *B_Timer_findTask(_u32 p_u32TaskId)
{
	BTimer_s *pstTimer = g_pstBTimer;
	for (int i = 0; i < pstTimer->u8MaxTaskNum; i++)
	{
		ITimerTask_s *pstTask = pstTimer->pstTaskList + i;		
		if (pstTask->stTask.u32TaskId == p_u32TaskId){
			return pstTask;
		}
	}
	DBG_ASSERT(0);
	return NULL;
}

_INT B_Timer_removeTask(_u32 p_u32TaskId)
{
	ITimerTask_s *pstTask = B_Timer_findTask(p_u32TaskId);
	lock(&g_pstBTimer->stLock);
	if (pstTask->bIsValid){// ��Ч���޸�
		pstTask->bIsStop = true;		
	}		
	unlock(&g_pstBTimer->stLock);		
	return RET_SUCCESS;
}
#endif //OS_NRF
