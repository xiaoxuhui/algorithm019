#include "GSGString.h"
#include "MathGSG.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

 _VOID GSG_sprintf(_CHAR *p_szBuffer, const _CHAR *p_szFormat, ...)
 {
	 size_t u8Offset = 0;
	 size_t u8StrLen = (size_t)strlen(p_szFormat);

	 _CHAR *strTemp = NULL;

	 va_list args;
	 va_start(args, p_szFormat);

	 for (_u8 i = 0; i < u8StrLen; i++)
	 {
		 _CHAR cChar = p_szFormat[i];
		 if (cChar == '%'){
			 i++;
			 if (i >= u8StrLen){
				 break;
			 }
			 cChar = p_szFormat[i];
			 switch (cChar)
			 {
			 case 'd':
			 {
						 _s32 nValue = va_arg(args, _s32);
						 strTemp = GSG_s32toa(nValue, p_szBuffer + u8Offset, false);
						 u8Offset += strlen(strTemp);
						 break;
			 }
			 case 'u':
			 {
						 _u32 nValue = va_arg(args, _u32);
						 strTemp = GSG_u32toa(nValue, p_szBuffer + u8Offset, false);
						 u8Offset += strlen(strTemp);
						 break;
			 }
			 case 's':
			 {
						 strTemp = va_arg(args, char*);
						 strcpy(p_szBuffer + u8Offset, strTemp);
						 u8Offset += strlen(strTemp);
						 break;

			 }
			 case 'x':
			 {
						 _s32 nValue = va_arg(args, _s32);
						 strTemp = GSG_u32toa(nValue, p_szBuffer + u8Offset, true);
						 u8Offset += strlen(strTemp);
						 break;
			 }
			 case 'f':
			 {
						 _DOUBLE nValue = va_arg(args, _DOUBLE);
						 strTemp = GSG_ftoa(nValue, p_szBuffer + u8Offset);
						 u8Offset += strlen(strTemp);
						 break;
			 }
			 default:
				 p_szBuffer[u8Offset] = cChar;
				 u8Offset++;
				 break;
			 }
		 }
		 else{
			 p_szBuffer[u8Offset] = cChar;
			 u8Offset++;
		 }

	 }
	 p_szBuffer[u8Offset] = '\0';

	 va_end(args);
 }

 _BOOL GSG_isHexString(const _CHAR *p_szHexString)
 {
	 size_t nLen = strlen(p_szHexString);
	 if (nLen == 0){
		 return false;
	 }
	 for (size_t i = 0; i < nLen; i++){// 
		 if (!GSG_isHexChar(p_szHexString[i])){
			 return false;
		 }
	 }
	 return true;
 }

 _BOOL GSG_isHexChar(const _CHAR p_cHex)
 {
	 const _CHAR	szValidChar[] = "0123456789abcdefABCDEF";
	 for (size_t i = 0; i < strlen(szValidChar); i++){
		 if (p_cHex == szValidChar[i]){
			 return true;
		 }
	 }
	 return false;
 }

