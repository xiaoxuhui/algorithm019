#include "SlipWindow.h"
#include "GSG.h"
#include "MathGSG.h"

typedef struct _SlipWindow_s
{
	_u32                nWinSize;
	_u32                nCurIndex;
	_u32                nUsedSize;

	_s32*				szElemList;
	_s64				s64ElemSum;
} SlipWindow_s;


_INT SlipWindow_create(const _u32 p_nWindowSize)
{
	SlipWindow_s *pstWindow = SYS_MALLOC(sizeof(SlipWindow_s));
	DBG_ASSERT(pstWindow != NULL);
	
	pstWindow->nWinSize = p_nWindowSize;
	pstWindow->szElemList = SYS_MALLOC(sizeof(_s32)* p_nWindowSize);
	DBG_ASSERT(pstWindow->szElemList != NULL);
	pstWindow->nCurIndex = 0;
	pstWindow->nUsedSize = 0;
	pstWindow->s64ElemSum = 0;
	
	return (_INT)pstWindow;
}

_VOID SlipWindow_reset(_INT p_hHandle)
{
	CHECK_NULL(p_hHandle);
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	pstWindow->nCurIndex = 0;
	pstWindow->nUsedSize = 0;
	pstWindow->s64ElemSum = 0;
}

_VOID SlipWindow_destroy(_INT p_hHandle)
{
	CHECK_NULL(p_hHandle);
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	SYS_FREE(pstWindow->szElemList);
	SYS_FREE(pstWindow);
}

_VOID SlipWindow_push(_INT p_hHandle, _s32 p_s32Data)
{
	DBG_ASSERT(0 != p_hHandle);
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	pstWindow->s64ElemSum += p_s32Data;
	DBG_ASSERT(pstWindow->s64ElemSum < (1LL << 31) && pstWindow->s64ElemSum > -(1LL << 31));
  
	if (pstWindow->nUsedSize < pstWindow->nWinSize){
		pstWindow->nUsedSize++;
	}
	else{
		pstWindow->s64ElemSum -= pstWindow->szElemList[pstWindow->nCurIndex];
	}
  
	pstWindow->szElemList[pstWindow->nCurIndex] = p_s32Data;
	pstWindow->nCurIndex = (pstWindow->nCurIndex + 1) % pstWindow->nWinSize;  
	return;
}

_s32 SlipWindow_getAverage(_INT p_hHandle)
{
	DBG_ASSERT(0 != p_hHandle);
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	if (pstWindow->nUsedSize == 0){
		return 0;
	}
	//return (_s32)(pstWindow->s64ElemSum / pstWindow->nUsedSize);
	return GSG_div((_s32)pstWindow->s64ElemSum, pstWindow->nUsedSize);
}

_s64 SlipWindow_getSum(_INT p_hHandle)
{
	DBG_ASSERT(0 != p_hHandle);
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	if (pstWindow->nUsedSize == 0){
		return 0;
	}
	return pstWindow->s64ElemSum;
}

_s32 SlipWindow_getDeltaAverage(_INT p_hHandle)
{
	DBG_ASSERT(0 != p_hHandle);
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	if (pstWindow->nUsedSize <= 1){
		return 0;
	}
	_u32 u32Index_front = (pstWindow->nUsedSize == pstWindow->nWinSize) ? pstWindow->nCurIndex : 0;
	_u32 u32Index_end = (pstWindow->nCurIndex + pstWindow->nWinSize - 1) % pstWindow->nWinSize;
	_s32 s32Sum_delta = pstWindow->szElemList[u32Index_end] - pstWindow->szElemList[u32Index_front];
	return GSG_div(s32Sum_delta, pstWindow->nUsedSize - 1);
}

_s32 SlipWindow_front(_INT p_hHandle)
{
	DBG_ASSERT(0 != p_hHandle);
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	if (pstWindow->nUsedSize == 0){
		return 0;
	}

	_u32 u32Index_front = (pstWindow->nUsedSize == pstWindow->nWinSize) ? pstWindow->nCurIndex : 0;
	return pstWindow->szElemList[u32Index_front];
}

_BOOL SlipWindow_isFull(_INT p_hHandle)
{
	SlipWindow_s *pstWindow = (SlipWindow_s*)p_hHandle;
	return (pstWindow->nUsedSize == pstWindow->nWinSize);
}
