#include "DirTool.h"
#include "GSG.h"
#if defined WIN32 || defined _WIN32 || defined WINCE
#include <windows.h>
#include <io.h>
#else
#include <stdio.h>
#endif


_BOOL isDirExist(const _CHAR* p_szDirName, const _INT p_nDirLen)
{
#if defined WIN32 || defined _WIN32 || defined WINCE
	if ((_access(p_szDirName, 0)) != -1)
	{
		return true;
	}
	return false;
	//WIN32_FIND_DATA fd;
	//HANDLE hFind = FindFirstFile(p_szDirName, &fd);
	//if ((hFind != INVALID_HANDLE_VALUE) && (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
	//{
	//	//Ŀ¼����  
	//	ret = true;
	//}
	//FindClose(hFind);
#else
	return false;
#endif
}

void DT_rmFile(const _CHAR* p_szDirName, const _INT p_nDirLen)
{
#if defined WIN32 || defined _WIN32 || defined WINCE
	DeleteFile(p_szDirName);
#else
	remove(p_szDirName);
#endif
}

_BOOL DT_creatDir(const _CHAR* p_szDirName, const _INT p_nDirLen)
{
	if (isDirExist(p_szDirName, p_nDirLen))
	{
		return true;
	}
#if defined WIN32 || defined _WIN32 || defined WINCE
	if (!CreateDirectory(p_szDirName, NULL))
	{
		return false;
	}
#endif
	return true;
}

_BOOL DT_GetCurExeDir(_CHAR* p_szDir, const _INT p_nDirBuffLen, _INT* p_nRealDirLen)
{
#if defined WIN32 || defined _WIN32 || defined WINCE
	char work_path[_MAX_PATH] = { 0 };
	_INT  nRet = GetModuleFileName(NULL, work_path, _MAX_PATH);  //�õ�����ģ��.exeȫ·�� 
	if (nRet <= 0 ){
		return false;
	}
	*(strrchr(work_path, '\\') + 1) = 0;       //ȥ�������ļ���  
	memcpy(p_szDir, work_path, strlen(work_path));
	*p_nRealDirLen = strlen(work_path);
	//printf("GetCurExeDir=%s\n", p_szDir);
#endif
	return true;
}

_BOOL DT_isExistDir(const _CHAR* p_szDirName, const _INT p_nDirLen)
{
	if (isDirExist(p_szDirName, p_nDirLen))
	{
		return true;
	}
	return false;
}

_BOOL DT_getFileWholeName(const _CHAR* p_szFileName, _CHAR* p_szFileName_whole)
{
#if defined WIN32 || defined _WIN32 || defined WINCE
	_CHAR szExeDir[_MAX_PATH] = { 0 };
	_INT nDirLen = 0;
	if (!DT_GetCurExeDir(szExeDir, _MAX_PATH, &nDirLen)){ 
		return false; 
	}
	SPRINTF(p_szFileName_whole, "%s/%s", szExeDir, p_szFileName);
#endif
	return true;
}
