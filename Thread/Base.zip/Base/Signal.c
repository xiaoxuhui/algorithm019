#include "Signal.h"
#include <string.h>


#ifdef WIN32

#elif defined OS_RTOS
#else
#include <pthread.h>
_VOID initSignal(Signal_Thread* p_pSignal)
{
	memset(p_pSignal,0,sizeof(pthread_cond_t));
	pthread_cond_init(p_pSignal,NULL);
}

_VOID waitSignal(Signal_Thread* p_pSignal, Lock_s* p_sLock)
{
	pthread_cond_wait(p_pSignal, &p_sLock->mutex);
}

_VOID destorySignal(Signal_Thread* p_pSignal)
{
	pthread_cond_destroy(p_pSignal);
}

_VOID resumeSignal(Signal_Thread* p_pSignal)
{
	pthread_cond_signal(p_pSignal);
}

#endif