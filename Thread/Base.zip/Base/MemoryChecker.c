#include "MemoryChecker.h"

#ifdef MEM_CHECK_ON


#include "B_Timer.h"
#include "CodeDef.h"
#include "SysMemory.h"
#include "SysTime.h"
#include <string.h>
#include <assert.h>

_VOID Memory_Init(_u8* p_pPointer, _u8 p_Value, _u8 p_len)
{
	assert(NULL != p_pPointer);

	memset(p_pPointer, p_Value, p_len);
}

_VOID Memory_Check(const _CHAR *p_szFileName, _u8* p_pPointer, _u8 p_Value, _u8 p_len)
{
	assert(NULL != p_pPointer);

	for (_u8 index = 0; index < p_len; index++)
	{
		if (*(p_pPointer + index) != p_Value)
		{
			_PRINT_LN_T("Memory error:%x e/a:0x%u/0x%u in %s", (_u32)p_pPointer, (_u32)p_Value, *(p_pPointer + index), p_szFileName);
			waitTime(10);
			assert(false);
		}
	}
}

#endif // MEM_CHECK_ON

