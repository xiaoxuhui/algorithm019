#include "GetFileName.h"
#ifdef OS_LINUX

#include "GSG.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>

int GSG_findFileName(char *p_pBasePath, char *p_pFindFileName, char *p_pFileName)
{
	DIR *dir= opendir(p_pBasePath);
	struct dirent *ptr;
	char img_path[128];
	int img_num = 0;

	if (dir == NULL){
		_PRINT_LN_T("Open dir error...");
		return -1;
	}

	while ((ptr = readdir(dir)) != NULL)
	{
		if (strcmp(ptr->d_name, ".") == 0 || strcmp(ptr->d_name, "..") == 0)    ///current dir OR parrent dir
			continue;
		else if (ptr->d_type == 8)    ///file
		{

			strcpy(img_path, ptr->d_name);
			if (strstr(img_path, p_pFindFileName) != NULL)
			{
				strcpy(p_pFileName, img_path);
				return 0;
			}
			memset(img_path, 0, sizeof(img_path));
		}
		else
		{
			continue;
		}
	}
	closedir(dir);
	return -1;
}


#endif // OS_LINUX
