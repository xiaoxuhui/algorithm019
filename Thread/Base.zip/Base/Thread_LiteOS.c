#include "Thread.h"
#include "Signal.h"
#include "CodeDef.h"
#include <stdio.h>
#include "SysMemory.h"
#include "SysTime.h"

#if  (defined  OS_LITEOS)

#include <pthread.h>
#include "Signal.h"
#include <sys/prctl.h>

typedef enum _SignalThread_Status_e
{
	SignalStatus_Suspend = 0,//�ź�״̬����
	SignalStatus_Resume = 1,//�ź�״̬����
}SignalThread_Status_e;

typedef struct _Thread_Status_Linux_s
{
	unsigned long int	  pHandle; //�߳̾��
	_BOOL				  bStopFlag;//ֹͣ��־
	_BOOL				  bExitFlag;//ʵ���˳����
	_BOOL				  bInFuncFlag;//�����û�������־
	Lock_s				  sLock;//�ź���
	Signal_Thread		  nThreadSignal;//�߳��ź�
	SignalThread_Status_e eSignalStatus;//�߳��ź�״̬
	pthread_attr_t		  attr;
	_CHAR*				  pszStackPoint;//ջָ��
	_INT				  nStackSize;//ջ��С
	_CHAR				  szThreadName[16];//�߳���,�ݶ�16���ֽ�
}Thread_Status_Linux_s;


void* ThreadFunc_Signal(void* p_pData)
{
	ThreadInfo_s* pThreadInfo = (ThreadInfo_s*)p_pData;
	CHECK_NULL(pThreadInfo->pHandle, NULL);
	Thread_Status_Linux_s* pStatusLinux = (Thread_Status_Linux_s*)pThreadInfo->pHandle;
	if (strlen(pStatusLinux->szThreadName) != 0)
	{
		prctl(PR_SET_NAME, pStatusLinux->szThreadName, 0, 0, 0);
	}
	pStatusLinux->bInFuncFlag = true;
	ThreadFuncRet_e nRet = RET_THREAD_CONTINUE;
	while (nRet == RET_THREAD_CONTINUE)
	{
		if (THREAD_SIGNAL == pThreadInfo->eThreadMode)
		{
			lock(&pStatusLinux->sLock);
			while (SignalStatus_Suspend == pStatusLinux->eSignalStatus)
			{
				waitSignal(&pStatusLinux->nThreadSignal, &pStatusLinux->sLock);
				//printf("WaiteSignal!!\n");
			}
			unlock(&pStatusLinux->sLock);
		}

		nRet = pThreadInfo->FuncBody(pThreadInfo->pData);
		if (pStatusLinux->bStopFlag)
		{
			break;
		}
	}
	pStatusLinux->bExitFlag = true;
	return NULL;
}

//�����߳�
_BOOL createThread(ThreadInfo_s* p_stThreadInfo)
{
	return true;
}

//�����߳�
_VOID destroyThread(ThreadInfo_s* p_stThreadInfo)
{

}

_BOOL startThread(ThreadInfo_s* p_stThreadInfo)
{
	CHECK_NULL(p_stThreadInfo, false);
	p_stThreadInfo->pHandle = (void*)SYS_MALLOC(sizeof(Thread_Status_Linux_s));
	Thread_Status_Linux_s* pStatusLinux = (Thread_Status_Linux_s*)p_stThreadInfo->pHandle;
	pStatusLinux->bStopFlag = false;
	pStatusLinux->bExitFlag = false;
	pStatusLinux->bInFuncFlag = false;
	memcpy(pStatusLinux->szThreadName,p_stThreadInfo->szThreadName,15);
	if (THREAD_SIGNAL == p_stThreadInfo->eThreadMode)
	{
		initLock(&pStatusLinux->sLock);
		initSignal(&pStatusLinux->nThreadSignal);
		pStatusLinux->eSignalStatus = SignalStatus_Suspend;
	}
	pthread_attr_init(&pStatusLinux->attr);
	if (p_stThreadInfo->u16ThreadStackSize != 0)
	{
		//printf("startThread u16ThreadStackSize=%d!", p_stThreadInfo->u16ThreadStackSize);
		pStatusLinux->pszStackPoint = SYS_MALLOC(1024 * p_stThreadInfo->u16ThreadStackSize);
		//pthread_attr_setstack(&pStatusLinux->attr, pStatusLinux->pszStackPoint, 1024 * p_stThreadInfo->u16ThreadStackSize);
		pthread_attr_setstackaddr(&pStatusLinux->attr, pStatusLinux->pszStackPoint);
		pthread_attr_setstacksize(&pStatusLinux->attr, 1024*p_stThreadInfo->u16ThreadStackSize);
	}
	int      detachState;
	detachState = PTHREAD_CREATE_DETACHED;
	_INT nRet = pthread_attr_setdetachstate(&pStatusLinux->attr, detachState);
	if (nRet != 0) {
		return false;
	}
	pthread_t th;
	_INT ret = pthread_create(&th, &pStatusLinux->attr, ThreadFunc_Signal, (void*)p_stThreadInfo);
	if (ret != 0){

		if (THREAD_SIGNAL == p_stThreadInfo->eThreadMode)
		{
			deleteLock(&pStatusLinux->sLock);
			destorySignal(&pStatusLinux->nThreadSignal);
		}
		if (pStatusLinux->pszStackPoint)
		{
			SYS_FREE(pStatusLinux->pszStackPoint);
			pStatusLinux->pszStackPoint = NULL;
		}
		SYS_FREE(p_stThreadInfo->pHandle);
		return false;
	}
	pStatusLinux->pHandle = th;
	pthread_detach(pStatusLinux->pHandle);
	return true;
}

_VOID stopThread(ThreadInfo_s* p_stThreadInfo)
{
	CHECK_NULL(p_stThreadInfo);
	CHECK_NULL(p_stThreadInfo->pHandle);


	//_PRINT_("stopThread11111 Begin !\n");
	Thread_Status_Linux_s* pStatusLinux = (Thread_Status_Linux_s*)p_stThreadInfo->pHandle;
	//_PRINT_("stopThread22222 Begin !\n");
	pStatusLinux->bStopFlag = true;
	//modify by xxh at 2017 - 12 - 04 TODO �˴����ܻᵼ�������߳��޷����У���LiteOS�³��ֹ����紫���̳߳�ʼ��ʧ�ܵ����
	//if(!pStatusLinux->bExitFlag)
	//{
	//	pthread_cancel(pStatusLinux->pHandle);
	//}
	if (THREAD_SIGNAL == p_stThreadInfo->eThreadMode)
	{
		resumeThread(p_stThreadInfo);
		while (true)
		{
			//���û��̷߳�������ʱ��������û��̷߳���ִ�������kill���û��̷߳����������˳���
			//����û��̷߳���δִ���꣬�ͽ������źš��ṹ���ͷŵĻ����и��ʱ������������ѳ��֣�
			//����Ϊ��������û��̷߳�������
			if (!pStatusLinux->bInFuncFlag)
			{
				deleteLock(&pStatusLinux->sLock);
				destorySignal(&pStatusLinux->nThreadSignal);
				break;
			}
			if (pStatusLinux->bExitFlag)
			{
				deleteLock(&pStatusLinux->sLock);
				destorySignal(&pStatusLinux->nThreadSignal);
				break;
			}
			waitTime(10);
		}
	}
	//_PRINT_("stopThread333333 Begin !pStatusLinux=%p\n", pStatusLinux);
	_u64  u64CurrentTime = getCurSysTime_ms();
	while (true)
	{
		if (pStatusLinux->bExitFlag || getCurSysTime_ms() - u64CurrentTime > 10000)
		{
			//_PRINT_LN("stopThread Free Begin bExitFlag=%d!", pStatusLinux->bExitFlag);
			pthread_attr_destroy(&pStatusLinux->attr);
			if (pStatusLinux->pszStackPoint)
			{
				SYS_FREE(pStatusLinux->pszStackPoint);
				pStatusLinux->pszStackPoint = NULL;
			}
			SYS_FREE(p_stThreadInfo->pHandle);
			break;

		}
		waitTime(10);
	}
	//_PRINT_("stopThread444444 Begin !\n");
}

_BOOL resumeThread(ThreadInfo_s* p_stThreadInfo)
{
	CHECK_NULL(p_stThreadInfo, false);
	CHECK_NULL(p_stThreadInfo->pHandle, false);
	CHECK_ET_VALUE(p_stThreadInfo->eThreadMode, THREAD_SIGNAL, false);
	Thread_Status_Linux_s* pStatusLinux = (Thread_Status_Linux_s*)p_stThreadInfo->pHandle;
	//printf("resumeThread_Signal In!\n");
	if (SignalStatus_Suspend == pStatusLinux->eSignalStatus)
	{
		lock(&pStatusLinux->sLock);
		pStatusLinux->eSignalStatus = SignalStatus_Resume;
		resumeSignal(&pStatusLinux->nThreadSignal);
		unlock(&pStatusLinux->sLock);
	}
	//printf("resumeThread_Signal Out!\n");
	return true;
}
_BOOL suspendThread(ThreadInfo_s* p_stThreadInfo)
{
	CHECK_NULL(p_stThreadInfo, false);
	CHECK_NULL(p_stThreadInfo->pHandle, false);
	CHECK_ET_VALUE(p_stThreadInfo->eThreadMode, THREAD_SIGNAL, false);
	//printf("SignalThread_Suspend In!\n");
	Thread_Status_Linux_s* pStatusLinux = (Thread_Status_Linux_s*)p_stThreadInfo->pHandle;
	if (SignalStatus_Resume == pStatusLinux->eSignalStatus)
	{
		lock(&pStatusLinux->sLock);
		pStatusLinux->eSignalStatus = SignalStatus_Suspend;
		unlock(&pStatusLinux->sLock);
	}
	//printf("SignalThread_Suspend Out!\n");
	return true;
}


#endif