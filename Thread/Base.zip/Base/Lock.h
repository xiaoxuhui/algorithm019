#ifndef _LOCK_H_
#define _LOCK_H_

#include "TypeDef.h"

#ifdef WIN32

#elif defined OS_RTOS
#ifdef CC2642XX
#include <ti/posix/iar/pthread.h>
#else
#include <ti/sysbios/posix/pthread.h>
#endif
#elif defined OS_LINUX_DRIVER
#include <linux/mutex.h>
#elif defined OS_NRF
#include "sdk_common.h"
#include "app_util_platform.h"
#else
#include <pthread.h>
#endif


typedef struct _Lock_s
{
#ifdef WIN32
	_VOID * pHandler;
#elif  defined OS_LINUX_DRIVER
	struct mutex devlock;
#elif  defined OS_NRF
	const _CHAR *szFileName;
	_u32      u32Line;
	_u32			u32BeginTime;
	_u32			u32EndTime;
	_BOOL			bIsLocked;
#else
	pthread_mutex_t mutex;
#endif
	
}Lock_s;


#ifdef OS_NRF
//#define initLock(p_pLock)			//	��ʼ����
//#define deleteLock(p_pLock)		//	������
//#define lock(p_pLock) CRITICAL_REGION_ENTER()
//#define unlock(p_pLock) CRITICAL_REGION_EXIT()
extern _u16 g_u16LockNum;
extern _s32 g_s32LockTime_max;
_VOID initLock(Lock_s* p_pLock);
_VOID deleteLock(Lock_s* p_pLock);
_VOID GSG_lock(Lock_s* p_pLock,const _CHAR *p_szFileName,const _u32 p_u32Line);
_VOID GSG_unlock(Lock_s* p_pLock);
_VOID GSG_lock_check(Lock_s* p_pLock);

#define lock(p_pLock) 		CRITICAL_REGION_ENTER();if(g_u16LockNum == 0){GSG_lock(p_pLock,__FILE__, __LINE__);};g_u16LockNum++
#define unlock(p_pLock) 	g_u16LockNum--;if(g_u16LockNum == 0) { GSG_unlock(p_pLock);CRITICAL_REGION_EXIT(); } GSG_lock_check(p_pLock) //(p_pLock)->u32EndTime = getUpTime_us(); 

#else
//��ʼ����
_VOID initLock(Lock_s* p_pLock);
//������
_VOID deleteLock(Lock_s* p_pLock);
//����
_VOID lock(Lock_s* p_pLock);
//����
_VOID unlock(Lock_s* p_pLock);
#endif

#endif	//_LOCK_H_

