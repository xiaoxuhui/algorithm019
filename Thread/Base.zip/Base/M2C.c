#include "M2C.h"
#include "CodeDef.h"

#define MAX_PITCH				x90_U16_MAX
#define MAX_YAW					x90_U16_MAX
#define MIN_DEGREE_VALUE		(U16_MAX >> 1)
#define M2S_COUNT				10			//�˶�����ֹ��Ҫ�����Ĵ���

typedef _s32(*toDegreeX90)(const _s32 p_s32Degree_Origin, const _s32 p_s32Degree);
typedef struct _M2CCtrl_s
{// 1������Ŀ�����Ϣ���������нǶ���Ϣ���Ŵ���U16_MAX��
	_s32			s32DegreeX90_min;		// ͳ�������ڵĽǶ���Сֵ
	_s32			s32DegreeX90_max;		// ͳ�������ڵĽǶ����ֵ
	_s32			s32DegreeX90_last;		// У׼��[-90,90]�ڵ��ϸ��Ƕ�ֵ
	_s32			s32DegreeX90Delta_last;	// �ϸ������ڵĽǶȱ仯ֵ

	_s32			s32Degree_Last;			//	�ϴνǶ�ֵ���Ŵ���U16_MAX��
	_s32			s32Degree_Origin;		//	ԭʼ�Ƕ�ֵ���Ŵ���U16_MAX��
	_BOOL			bIsMoving;				//	�Ƿ����˶�״̬
	_u16			nContinueCount;			//	��ͬ״̬������	

	_s16			s16Position_Origin;		//	ԭʼ����ֵ
	_s16			s16Position_Last;		//	�ϴ�����ֵ
	_s32			s32Direction;			//	���귽��XΪ����YΪ��

	toDegreeX90		fToDegreeX90;
}M2CCtrl_s;

typedef struct _M2C_s
{
	M2C_PID_s		stPIDInfo;				//	PID������Ϣ
	M2CCtrl_s		stCtrl_X;				//	X������������Ϣ
	M2CCtrl_s		stCtrl_Y;				//	Y������������Ϣ
	_BOOL			bDIsEnable;				//	�ر�D����
}M2C_s;

static M2C_s *g_pstM2C = NULL;

_s32 M2C_X180toX90(const _s32 p_s32Degree_Origin, const _s32 p_s32DegreeSrc)
{//	��[-180,180]�ĽǶ�ת����[-90,90]�ĽǶȣ����Ŵ���U16_MAX��
	if (p_s32DegreeSrc > MAX_PITCH){
		return (MAX_PITCH << 1) - p_s32DegreeSrc;
	}
	if (p_s32DegreeSrc < -MAX_PITCH){
		return -((MAX_PITCH << 1) + p_s32DegreeSrc);
	}
	return p_s32DegreeSrc;
}

_s32 M2C_toYaw(const _s32 p_s32Degree_Origin, const _s32 p_s32Yaw_Src)
{//��yawת����[-90,90]
	_s32 s32Yaw_Origin = p_s32Degree_Origin;
	_s32 s32Yaw = (p_s32Yaw_Src + x360_U16_MAX - s32Yaw_Origin) % x360_U16_MAX;
	if (s32Yaw >= x180_U16_MAX){
		return M2C_X180toX90(0, s32Yaw - x360_U16_MAX);
	}
	return M2C_X180toX90(0, s32Yaw);
}

_BOOL M2C_init(const M2C_PID_s* p_pstPID, const MotionInfoV2_s* p_pstMotionInfo, const Point_s* p_pstCoordinate)
{
	INIT_STATIC_PARAM(g_pstM2C, M2C_s, false);
	g_pstM2C->stPIDInfo = *p_pstPID;

	g_pstM2C->stCtrl_X.s16Position_Origin = p_pstCoordinate->s16X;
	g_pstM2C->stCtrl_X.s32Degree_Origin = p_pstMotionInfo->szOrientation[EULER_YAW];
	g_pstM2C->stCtrl_X.s32Degree_Last = p_pstMotionInfo->szOrientation[EULER_YAW];
	g_pstM2C->stCtrl_X.fToDegreeX90 = M2C_toYaw;
	g_pstM2C->stCtrl_X.s32Direction = 1;

	g_pstM2C->stCtrl_Y.s16Position_Origin = p_pstCoordinate->s16Y;
	g_pstM2C->stCtrl_Y.s32Degree_Origin = p_pstMotionInfo->szOrientation[EULER_PITCH];
	g_pstM2C->stCtrl_Y.s32Degree_Last = p_pstMotionInfo->szOrientation[EULER_PITCH];
	g_pstM2C->stCtrl_Y.fToDegreeX90 = M2C_X180toX90;
	g_pstM2C->stCtrl_Y.s32Direction = -1;
	return true;
}

_VOID M2C_uninit(_VOID)
{
	SYS_FREE(g_pstM2C);
}

#define M2C_resetMinMaxNum(num,min,max)				do {min = num; max = num;} while (false)
#define M2C_updateMinMaxNum(num,min,max)			do {if (min > num){min = num; } if (max < num){max = num; }} while (false)
#define M2C_updateMinMax(p_pstCtrl, s32Degree)		M2C_updateMinMaxNum(s32Degree, p_pstCtrl->s32DegreeX90_min, p_pstCtrl->s32DegreeX90_max)
#define M2C_resetMinMax(p_pstCtrl, s32Degree)		M2C_resetMinMaxNum(s32Degree, p_pstCtrl->s32DegreeX90_min, p_pstCtrl->s32DegreeX90_max)

_s16 M2C_toPos_withoutD(M2CCtrl_s *p_pstCtrl, const _s32 p_s32DegreeX90, const M2C_PID_s *p_pstPID)
{
	_s32 s32DegreeX90_Origin = p_pstCtrl->fToDegreeX90(p_pstCtrl->s32Degree_Origin, p_pstCtrl->s32Degree_Origin);
	return (p_pstCtrl->s32Direction * ((((p_s32DegreeX90 - s32DegreeX90_Origin) * p_pstPID->u16P) >> 16) >> p_pstPID->u16Scale) + p_pstCtrl->s16Position_Origin);
}

_s16 M2C_toPos_withD(M2CCtrl_s *p_pstCtrl, const _s32 p_s32DegreeX90, const M2C_PID_s *p_pstPID)
{// �����˶�״̬��Ϊ��ֹ״̬����ͣ��PID�㷨����ǰ��ʹ��PID����
	// ˵��: s32Degree_dst = (s32Degree_cur * P + s32Degree_delta * D)
	_s32 s32DegreeX90_delta = p_s32DegreeX90 - p_pstCtrl->s32DegreeX90_last;
	_s32 s32DegreeX90_dst = (p_s32DegreeX90 * p_pstPID->u16P + (s32DegreeX90_delta - p_pstCtrl->s32DegreeX90Delta_last) * p_pstPID->u16D) >> p_pstPID->u16Scale;
	p_pstCtrl->s32DegreeX90_last = p_s32DegreeX90;
	p_pstCtrl->s32DegreeX90Delta_last = s32DegreeX90_delta;

	_s32 s32DegreeX90_Origin = p_pstCtrl->fToDegreeX90(p_pstCtrl->s32Degree_Origin, p_pstCtrl->s32Degree_Origin);
	_s32 s32DegreeX90_delta_dst = s32DegreeX90_dst - (s32DegreeX90_Origin * p_pstPID->u16P >> p_pstPID->u16Scale);
	return p_pstCtrl->s32Direction * (s32DegreeX90_delta_dst >> 16) + p_pstCtrl->s16Position_Origin;
}

_VOID M2C_toPos_Base(M2CCtrl_s *p_pstCtrl, const _s32 p_s32Degree_Src, const M2C_PID_s *p_pstPID, _s16* p_s16Offset)
{
	_s32 s32DegreeX90 = p_pstCtrl->fToDegreeX90(p_pstCtrl->s32Degree_Origin, p_s32Degree_Src);
	_BOOL bIsMoving = p_pstCtrl->bIsMoving;
	M2C_updateMinMax(p_pstCtrl, s32DegreeX90);

	if (!g_pstM2C->bDIsEnable){// ������D����
		*p_s16Offset = M2C_toPos_withoutD(p_pstCtrl, s32DegreeX90, p_pstPID);
		return;
	}

	if (!bIsMoving)
	{// �����ھ�ֹ״̬�����˶�����С����ֱ��ʹ��ԭ����㼴��
		*p_s16Offset = M2C_toPos_withoutD(p_pstCtrl, s32DegreeX90, p_pstPID);
		if (p_pstCtrl->s32DegreeX90_max - p_pstCtrl->s32DegreeX90_min < MIN_DEGREE_VALUE){// ���Ӿ�ֹ״̬��Ϊ�˶�״̬��������PID�㷨����ǰ�㲻ʹ��PID����
			return;
		}
		// �����˶�״̬
		p_pstCtrl->bIsMoving = true;
		p_pstCtrl->s32DegreeX90_last = s32DegreeX90;
		p_pstCtrl->s32DegreeX90Delta_last = 0;
		p_pstCtrl->nContinueCount = 0;
		M2C_resetMinMax(p_pstCtrl, s32DegreeX90);
		return;
	}
	else
	{// �������˶�״̬����ʹ��PID�㷨
		// �����˶�״̬��Ϊ��ֹ״̬����ͣ��PID�㷨����ǰ��ʹ��PID����
		*p_s16Offset = M2C_toPos_withD(p_pstCtrl, s32DegreeX90, p_pstPID);

		if ((p_pstCtrl->s32DegreeX90_max - p_pstCtrl->s32DegreeX90_min) > MIN_DEGREE_VALUE){//	���ڳ����˶�״̬
			p_pstCtrl->nContinueCount = 0;// ��վ�ֹ����������
			M2C_resetMinMax(p_pstCtrl, s32DegreeX90);
			return;
		}

		p_pstCtrl->nContinueCount++;// ��ֹ��������������
		if (p_pstCtrl->nContinueCount >= M2S_COUNT){//	���뾲ֹ״̬
			p_pstCtrl->nContinueCount = 0;
			p_pstCtrl->bIsMoving = false;

			M2C_resetMinMax(p_pstCtrl, s32DegreeX90);
		}
	}
}

_VOID M2C_IMUtoPoint(const MotionInfoV2_s* p_pstMotionInfo_delta, const Point_s *p_pstCoordinate, const _u16 p_u16PixelPerDegree, const _s16 p_s16ProjectionAngle, Point_s *pstPoint_delta)
{
	pstPoint_delta->s16X = (g_pstM2C->stCtrl_X.fToDegreeX90(0, p_pstMotionInfo_delta->szOrientation[EULER_YAW]) * g_pstM2C->stPIDInfo.u16P) >> 16;
	pstPoint_delta->s16Y = (g_pstM2C->stCtrl_Y.fToDegreeX90(0, p_pstMotionInfo_delta->szOrientation[EULER_PITCH]) * g_pstM2C->stPIDInfo.u16P) >> 16;
}

#define M2C_toCoordinate_Base(stCtrl, s32Degree_Src, stPID, s16Offset) do \
{\
	M2C_toPos_Base(&stCtrl, s32Degree_Src, &stPID, &s16Offset); \
	stCtrl.s32Degree_Last = s32Degree_Src; \
	stCtrl.s16Position_Last = s16Offset; \
} while (false)

_VOID M2C_toCoordinate(const MotionInfoV2_s* p_pstMotionInfo, Point_s* p_pstCoordinate)
{
	M2C_toCoordinate_Base(g_pstM2C->stCtrl_X, p_pstMotionInfo->szOrientation[EULER_YAW], g_pstM2C->stPIDInfo, p_pstCoordinate->s16X);

	//_PRINT_LN_T("yaw(%d\t)-> x(\t%d),P:%d D:%d", O2Degree(p_pstMotionInfo->szOrientation[EULER_YAW], 1), p_pstCoordinate->s16X, g_pstM2C->stPIDInfo.u16P, g_pstM2C->stPIDInfo.u16D);

	M2C_toCoordinate_Base(g_pstM2C->stCtrl_Y, p_pstMotionInfo->szOrientation[EULER_PITCH], g_pstM2C->stPIDInfo, p_pstCoordinate->s16Y);
}

_VOID M2C_disableD(_VOID)
{
	g_pstM2C->bDIsEnable = false;
}


_VOID M2C_enableD(_VOID)
{
	g_pstM2C->bDIsEnable = true;
}

_VOID M2C_resetOriginInfo(const M2C_PID_s* p_pstPID, const Point_s* p_pstCoordinate, const MotionInfoV2_s* p_pstMotionInfo)
{
	g_pstM2C->stPIDInfo = *p_pstPID;
	//_PRINT_LN_T("resetOrigin(%d,%d)->(%d,%d)->(%d,%d)", g_pstM2C->stCtrl_X.s16Position_Origin, g_pstM2C->stCtrl_Y.s16Position_Origin,
	//	g_pstM2C->stCtrl_X.s16Position_Last, g_pstM2C->stCtrl_Y.s16Position_Last,
	//	p_pstCoordinate->s16X, p_pstCoordinate->s16Y);
	g_pstM2C->stCtrl_X.s16Position_Origin = p_pstCoordinate->s16X;
	g_pstM2C->stCtrl_X.s16Position_Last = p_pstCoordinate->s16X;
	g_pstM2C->stCtrl_X.s32Degree_Origin = p_pstMotionInfo->szOrientation[EULER_YAW];
	g_pstM2C->stCtrl_X.bIsMoving = false;

	g_pstM2C->stCtrl_Y.s16Position_Origin = p_pstCoordinate->s16Y;
	g_pstM2C->stCtrl_Y.s16Position_Last = p_pstCoordinate->s16Y;
	g_pstM2C->stCtrl_Y.s32Degree_Origin = p_pstMotionInfo->szOrientation[EULER_PITCH];
	g_pstM2C->stCtrl_Y.bIsMoving = false;	
}
