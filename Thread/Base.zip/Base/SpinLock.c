#include "SpinLock.h"
#include "CodeDef.h"


#ifdef WIN32

#include <Windows.h>
//��ʼ����
_VOID initSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);

	HANDLE hMutex = CreateMutex(NULL, FALSE, NULL);
	if (hMutex)
	{
		if (ERROR_ALREADY_EXISTS == GetLastError())
		{
			//_PRINT_("MutexLock ERROR_ALREADY_EXISTS");
			return;
		}
	}

	p_pSpinLock->pHandler = (_VOID*)hMutex;
}

//������
_VOID deleteSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	CHECK_NULL(p_pSpinLock->pHandler);

	ReleaseMutex(p_pSpinLock->pHandler);
	CloseHandle(p_pSpinLock->pHandler);
	p_pSpinLock->pHandler = NULL;
}

//����
_VOID spin_lock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	CHECK_NULL(p_pSpinLock->pHandler);

	WaitForSingleObject(p_pSpinLock->pHandler, INFINITE);

}

//����
_VOID spin_unlock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	CHECK_NULL(p_pSpinLock->pHandler);
	ReleaseMutex(p_pSpinLock->pHandler);
}

_VOID spin_lock_interrupt(SpinLock_s* p_pSpinLock)
{
	spin_lock_non_irq(p_pSpinLock);
}

_VOID spin_unlock_interrupt(SpinLock_s* p_pSpinLock)
{
	spin_unlock_non_irq(p_pSpinLock);
}
#elif defined OS_LINUX_DRIVER
//��ʼ����
_VOID initSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_lock_init(&(p_pSpinLock->stSpinLock));
}
_VOID deleteSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
}

_VOID spin_lock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_lock(&(p_pSpinLock->stSpinLock));
}

_VOID spin_unlock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_unlock(&(p_pSpinLock->stSpinLock));
}

_VOID spin_lock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_lock_irqsave(&(p_pSpinLock->stSpinLock), p_pSpinLock->ulParam);
}

_VOID spin_unlock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_unlock_irqrestore(&(p_pSpinLock->stSpinLock), p_pSpinLock->ulParam);
}
#elif defined OS_RTOS
//��ʼ����
_VOID initSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	GateHwi_Params stParam;
	GateHwi_Params_init(&stParam);
	GateHwi_construct(&(p_pSpinLock->stGateHwi), &stParam);
}

_VOID deleteSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	GateHwi_destruct(&(p_pSpinLock->stGateHwi));
}

_VOID spin_lock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	_u32 u32Arg = GateHwi_enter((GateHwi_Handle)(&(p_pSpinLock->stGateHwi)));
	p_pSpinLock->nArg = u32Arg;
}

_VOID spin_unlock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	GateHwi_leave((GateHwi_Handle)(&(p_pSpinLock->stGateHwi)), p_pSpinLock->nArg);
}

_VOID spin_lock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	_u32 u32Arg = GateHwi_enter((GateHwi_Handle)(&(p_pSpinLock->stGateHwi)));
	p_pSpinLock->nArg = u32Arg;
}

_VOID spin_unlock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	GateHwi_leave((GateHwi_Handle)(&(p_pSpinLock->stGateHwi)), p_pSpinLock->nArg);
}
#elif defined OS_NRF
	//��ʼ����
_VOID initSpinLock(SpinLock_s* p_pSpinLock)
{
//	CHECK_NULL(p_pSpinLock);
//	initLock((Lock_s *)p_pSpinLock);
}

//������
_VOID deleteSpinLock(SpinLock_s* p_pSpinLock)
{
		//TODO
//	CHECK_NULL(p_pSpinLock);
//	deleteLock((Lock_s *)p_pSpinLock);
}

_VOID spin_lock_non_irq(SpinLock_s* p_pSpinLock)
{
		//TODO
//	CHECK_NULL(p_pSpinLock);
//	lock((Lock_s *)p_pSpinLock);
}

_VOID spin_unlock_non_irq(SpinLock_s* p_pSpinLock)
{
	//TODO
//	CHECK_NULL(p_pSpinLock);
//	unlock((Lock_s *)p_pSpinLock);
}

_VOID spin_lock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_lock_non_irq(p_pSpinLock);
}

_VOID spin_unlock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_unlock_non_irq(p_pSpinLock);
}
#else
//��ʼ����
_VOID initSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	initLock((Lock_s *)p_pSpinLock);
}

//������
_VOID deleteSpinLock(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	deleteLock((Lock_s *)p_pSpinLock);
}

_VOID spin_lock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	lock((Lock_s *)p_pSpinLock);
}

_VOID spin_unlock_non_irq(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	unlock((Lock_s *)p_pSpinLock);
}

_VOID spin_lock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_lock_non_irq(p_pSpinLock);
}

_VOID spin_unlock_interrupt(SpinLock_s* p_pSpinLock)
{
	CHECK_NULL(p_pSpinLock);
	spin_unlock_non_irq(p_pSpinLock);
}
#endif
