#include "CMD_ParseTool.h"
#include "NetFuncDef.h"

_VOID ICP_popU32(_BYTE **pTempPos, _u32 *pOffset, const _u32 nBufferLen, _u32 *p_pu32Num)
{
	_u32 nTemp_u32 = 0;
	_u32 nSize = sizeof(_u32);
	*pOffset += nSize;
	CHECK_BUFFER_SIZE(*pOffset, nBufferLen);
	memcpy(&nTemp_u32, *pTempPos, nSize);
	*p_pu32Num = ntohl(nTemp_u32);
	*pTempPos += nSize;
}

_VOID ICP_popU16(_BYTE **pTempPos, _u32 *pOffset, const _u32 nBufferLen, _u16 *p_pu16Num)
{
	_u16 nTemp_u16 = 0;
	_u32 nSize = sizeof(_u16);
	*pOffset += nSize;
	CHECK_BUFFER_SIZE(*pOffset, nBufferLen);
	memcpy(&nTemp_u16, *pTempPos, nSize);
	*p_pu16Num = ntohs(nTemp_u16);
	*pTempPos += nSize;
}

_VOID ICP_popU8(_BYTE **pTempPos, _u32 *pOffset, const _u32 nBufferLen, _u8 *p_pu8Num)
{
	_u16 nSize = sizeof(_u8);
	*pOffset += nSize;
	CHECK_BUFFER_SIZE(*pOffset, nBufferLen);
	*p_pu8Num = **pTempPos;
	*pTempPos += nSize;
}

