#include "PerformanceLogger.h"
#include "SysTime.h"
#include "SysLog.h"
#include "BaseFile.h"
#include "SysPrint.h"
#include "SysMemory.h"
#include "PerformanceTime.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include "CodeDef.h"

typedef struct _TimeSegment_s
{
	bool		bIsIgnored;
	const char*	pszFunName;
	_u64		u64WasteTime;
}TimeSegment_s;

#define MaxCountStep  1000
typedef struct _TimeSegmentList_s
{
	TimeSegment_s	stTimeSegment[MaxCountStep];
	_u32			u32Count;

	char			*pszFunNameList;
	_u32			u32Offset;
}TimeSegmentList_s;

typedef struct _PLogger_s
{
	TimeSegmentList_s stTimeSegmentList;

	PerformanceTime_s	stSysime;
	_u64		u64TotalTime;
	_u32		u32ValidCount;
	_u64		u64ValidTime;
	_u32		u32DebugCount;
	_u64		u64DebugTime;
	_BOOL		bIsStoped;
}PLogger_s;

static PLogger_s *g_pstPLogger = NULL;
static bool g_bEnableFlag = false;

#define MAX_LEN_FUNNAME_LIST 1024 * 1024 * 2

_VOID insertTimeSegment(const char*	p_pszFunName)
{
	if (g_pstPLogger->stTimeSegmentList.u32Count >= MaxCountStep){
		_PRINT_("too many funs(%d)..\n", g_pstPLogger->stTimeSegmentList.u32Count);
		return;
	}
	_u32 nStrLen = strlen(p_pszFunName);
	if (g_pstPLogger->stTimeSegmentList.u32Offset + nStrLen > MAX_LEN_FUNNAME_LIST){
		_PRINT_("too many funName..\n");
		return;
	}

	char *pszCurrentFunName = g_pstPLogger->stTimeSegmentList.pszFunNameList + g_pstPLogger->stTimeSegmentList.u32Offset;
	memcpy(pszCurrentFunName, p_pszFunName, nStrLen);

	g_pstPLogger->stTimeSegmentList.stTimeSegment[g_pstPLogger->stTimeSegmentList.u32Count].u64WasteTime = 0;
	g_pstPLogger->stTimeSegmentList.stTimeSegment[g_pstPLogger->stTimeSegmentList.u32Count].pszFunName = pszCurrentFunName;
	g_pstPLogger->stTimeSegmentList.stTimeSegment[g_pstPLogger->stTimeSegmentList.u32Count].bIsIgnored = false;

	g_pstPLogger->stTimeSegmentList.u32Count++;
	g_pstPLogger->stTimeSegmentList.u32Offset = g_pstPLogger->stTimeSegmentList.u32Offset + nStrLen + 1;
}

_VOID writeInfo(const char *p_szInfo, const char *p_szReportFileName)
{
	CHECK_NULL(p_szReportFileName);		
#ifdef WIN32
	File_s stFile;
	int nRet = openFile(&stFile, p_szReportFileName, ADD_WRITE);
	if (nRet != 0)
	{
		_PRINT_("writeResult Open LogFile Failed..\n");
		return;
	}

	if (!writeFile(&stFile, p_szInfo, strlen(p_szInfo)))
	{
		_PRINT_("write log failed..\n");
	}

	closeFile(&stFile);
#else
	_PRINT_(p_szInfo);
#endif // WIN32
}

_VOID PLoggerImpl_updateWasteTime(_VOID)
{
	if (g_pstPLogger->stTimeSegmentList.u32Count > 0)
	{
		END_TIME_TEST(g_pstPLogger->stSysime);
		TimeSegment_s *pstTimeSegment = &g_pstPLogger->stTimeSegmentList.stTimeSegment[g_pstPLogger->stTimeSegmentList.u32Count - 1];

		_u64 currentWastTime = PASS_TIME(g_pstPLogger->stSysime);
		g_pstPLogger->u64TotalTime += currentWastTime;

		pstTimeSegment->u64WasteTime = currentWastTime;
		if (pstTimeSegment->bIsIgnored)
		{
			g_pstPLogger->u64DebugTime += currentWastTime;
			g_pstPLogger->u32DebugCount++;
		}
		else
		{
			g_pstPLogger->u64ValidTime += currentWastTime;
			g_pstPLogger->u32ValidCount++;
		}
	}
}

_VOID PLogger_init(_BOOL p_bEnable)
{
	g_bEnableFlag = p_bEnable;
	g_pstPLogger = (PLogger_s *)SYS_MALLOC(sizeof(PLogger_s));
	if (NULL == g_pstPLogger){
		_PRINT_("PLoggerImpl_init failed.\n");
		return;
	}
	memset(g_pstPLogger, 0, sizeof(PLogger_s));
	
	g_pstPLogger->stTimeSegmentList.pszFunNameList = (char*)SYS_MALLOC(MAX_LEN_FUNNAME_LIST);
	if (NULL != g_pstPLogger->stTimeSegmentList.pszFunNameList)
	{
		memset(g_pstPLogger->stTimeSegmentList.pszFunNameList, 0, MAX_LEN_FUNNAME_LIST);
		g_pstPLogger->stTimeSegmentList.u32Offset = 0;
	}
	else
	{
		_PRINT_("pszFunNameList Null!\n");
		return;
	}

	g_pstPLogger->bIsStoped = true;
	g_pstPLogger->stTimeSegmentList.u32Count = 0;
}

_VOID PLogger_uninit(_VOID)
{
	CHECK_NULL(g_pstPLogger);
	SYS_FREE(g_pstPLogger->stTimeSegmentList.pszFunNameList);
	SYS_FREE(g_pstPLogger);
}

_VOID PLogger_start(const char *p_pszFunName, ...)
{
	CHECK_ET_VALUE(g_bEnableFlag, true);
	
	char szFunName[1024] = { '0' };
	va_list args;
	va_start(args, p_pszFunName);
	vsprintf(szFunName, p_pszFunName, args);
	va_end(args);

	START_TIME_TEST(g_pstPLogger->stSysime);
	insertTimeSegment(szFunName);
	g_pstPLogger->bIsStoped = false;
}

_VOID PLogger_stop(_VOID)
{
	CHECK_ET_VALUE(g_bEnableFlag, true);
	CHECK_ET_VALUE(g_pstPLogger->bIsStoped, false);
	PLoggerImpl_updateWasteTime();
	g_pstPLogger->bIsStoped = true;
}

#define MIN_WASTE_PERCENT	0.5

_u64 PLogger_print(const char *p_pszTestName, const char *p_pszReportPath, const char *p_pszLogPath, const _u64 p_u64TotalWasteTime, const unsigned int p_u32MinWasteTime)
{
	CHECK_ET_VALUE(g_bEnableFlag, true, 0);

	SysTime_s stCurTime = getCurSysTime();

	char szMessageData[1024] = { 0 };
	sprintf(szMessageData, "%4d-%2d-%2d %2d:%2d:%2d [%s]waste(%8lld)us,total[(%8lld)us],debug[%8lld)us],details:\n", stCurTime.year, stCurTime.month, stCurTime.day, stCurTime.hour, stCurTime.minute, stCurTime.second, p_pszTestName, g_pstPLogger->u64ValidTime, p_u64TotalWasteTime, g_pstPLogger->u64DebugTime);
	writeInfo(szMessageData, p_pszReportPath);
	writeInfo(szMessageData, p_pszLogPath);


	for (size_t i = 0; i < g_pstPLogger->stTimeSegmentList.u32Count; i++)
	{
		TimeSegment_s *pstTimeSegment = &g_pstPLogger->stTimeSegmentList.stTimeSegment[i];
		if (pstTimeSegment->u64WasteTime < (_u64)p_u32MinWasteTime){
			continue;
		}


		char szMessage[128] = { 0 };
		float rate = pstTimeSegment->u64WasteTime * (float)100.0 / g_pstPLogger->u64ValidTime;
		if (rate >=(_FLOAT) MIN_WASTE_PERCENT){
			sprintf(szMessage, "\t%3d. [%50s]waste(%7lld)us,rate:%02.2f%%,\t%s\n", i + 1, pstTimeSegment->pszFunName, pstTimeSegment->u64WasteTime, rate, "----------");
		}
		else{
			sprintf(szMessage, "\t%3d. [%50s]waste(%7lld)us,rate:%02.2f%%\n", i + 1, pstTimeSegment->pszFunName, pstTimeSegment->u64WasteTime, rate);
		}

		writeInfo(szMessage, p_pszLogPath);

		char szWasteTime[32] = { 0 };
		sprintf(szWasteTime, "%lld\t", pstTimeSegment->u64WasteTime);
		writeInfo(szWasteTime, p_pszReportPath);
	}

	writeInfo("\n", p_pszReportPath);
	return g_pstPLogger->u64ValidTime;
}

_VOID PLogger_clear()
{
	CHECK_ET_VALUE(g_bEnableFlag, true);

	CHECK_NULL(g_pstPLogger);	

	g_pstPLogger->u32DebugCount = 0;
	g_pstPLogger->u32ValidCount = 0;
	g_pstPLogger->u64DebugTime = 0;
	g_pstPLogger->u64TotalTime = 0;
	g_pstPLogger->u64ValidTime = 0;
	g_pstPLogger->stTimeSegmentList.u32Count = 0;
	g_pstPLogger->stSysime.startTime = 0;
	g_pstPLogger->stSysime.endTime = 0;

	memset(g_pstPLogger->stTimeSegmentList.pszFunNameList, 0, MAX_LEN_FUNNAME_LIST);
	g_pstPLogger->stTimeSegmentList.u32Offset = 0;
	g_pstPLogger->bIsStoped = true;
}
