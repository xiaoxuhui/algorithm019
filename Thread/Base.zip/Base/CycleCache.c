#include "CycleCache.h"
#include "CodeDef.h"
#include "Lock.h"
#include "GSG.h"

typedef struct _CycleCache_s
{
	_CHAR	*pszCacheBuff;
	_u16	u16CacheSize;
	_u16	u16WritePos;
	_u16	u16ReadPos;

	_BOOL	bNeedLock;
	Lock_s	stLock;
}CycleCache_s;

#define C_CREATE_LOCK(p_bNeedLock,stLock)		if (p_bNeedLock){ initLock(&stLock); }
#define C_DESTROY_LOCK(p_bNeedLock,stLock)		if (p_bNeedLock){ deleteLock(&stLock); }
#define C_LOCK(p_bNeedLock, stLock)				if (p_bNeedLock){ lock(&stLock); }
#define C_UNLOCK(p_bNeedLock, stLock)			if (p_bNeedLock){ unlock(&stLock); }

_INT CycleCache_create(_u16 p_u16CacheSize,_BOOL p_bNeedLock)
{
	CycleCache_s *pstCycleCache = SYS_MALLOC(sizeof(CycleCache_s));
	DBG_ASSERT(pstCycleCache != 0);
	pstCycleCache->pszCacheBuff = SYS_MALLOC(p_u16CacheSize + 1);
	pstCycleCache->u16CacheSize = p_u16CacheSize;
	pstCycleCache->u16ReadPos = 0;
	pstCycleCache->u16WritePos = 0;
	pstCycleCache->bNeedLock = p_bNeedLock;

	C_CREATE_LOCK(pstCycleCache->bNeedLock, pstCycleCache->stLock);
	return (int)pstCycleCache;
}

_VOID CycleCache_destroy(_INT p_hHandle)
{
	DBG_ASSERT(p_hHandle != 0);
	CycleCache_s *pstCycleCache = (CycleCache_s *)p_hHandle;
	C_DESTROY_LOCK(pstCycleCache->bNeedLock, pstCycleCache->stLock);
	SYS_FREE(pstCycleCache->pszCacheBuff);
}

_BOOL CycleCache_push_base(CycleCache_s *pstCycleCache, const _CHAR *p_szData, const _u16 p_u16DataLen)
{
	_u16 u16ReadPos = pstCycleCache->u16ReadPos;
	_u16 u16WritePos = pstCycleCache->u16WritePos;

	if (u16ReadPos > u16WritePos)
	{
		_u16 u16FreeSize = u16ReadPos - u16WritePos;
		CHECK_BIG_ET_VALUE(u16FreeSize, p_u16DataLen, false);

		memcpy(pstCycleCache->pszCacheBuff + u16WritePos, p_szData, p_u16DataLen);
		pstCycleCache->u16WritePos += p_u16DataLen;
		return true;
	}

	_u16 u16LeftSize = u16ReadPos + pstCycleCache->u16CacheSize - u16WritePos;
	if (u16LeftSize < p_u16DataLen)
	{
		return false;
	}

	_u16 u16FreeSize_cur = pstCycleCache->u16CacheSize + 1 - u16WritePos;
	if (u16FreeSize_cur > p_u16DataLen)
	{
		memcpy(pstCycleCache->pszCacheBuff + u16WritePos, p_szData, p_u16DataLen);
		pstCycleCache->u16WritePos += p_u16DataLen;
	}
	else
	{
		memcpy(pstCycleCache->pszCacheBuff + u16WritePos, p_szData, u16FreeSize_cur);
		memcpy(pstCycleCache->pszCacheBuff, p_szData + u16FreeSize_cur, p_u16DataLen - u16FreeSize_cur);
		pstCycleCache->u16WritePos = p_u16DataLen - u16FreeSize_cur;
	}
	return true;
}


_BOOL CycleCache_push(_INT p_hHandle, const _CHAR *p_szData, const _u16 p_u16DataLen)
{
	DBG_ASSERT(p_hHandle != 0);
	CycleCache_s *pstCycleCache = (CycleCache_s *)p_hHandle;
	C_LOCK(pstCycleCache->bNeedLock, pstCycleCache->stLock);
	_BOOL bRet = CycleCache_push_base(pstCycleCache, p_szData, p_u16DataLen);
	C_UNLOCK(pstCycleCache->bNeedLock, pstCycleCache->stLock);
	return bRet;
}

_INT CycleCache_pop_base(CycleCache_s *pstCycleCache, _CHAR *p_szData, const _u16 p_u16BufferLen)
{
	_u16 u16ReadPos = pstCycleCache->u16ReadPos;
	_u16 u16WritePos = pstCycleCache->u16WritePos;
	if (u16ReadPos == u16WritePos){
		return 0;
	}
	else if (u16ReadPos < u16WritePos)
	{
		_u16 u16DataSize = u16WritePos - u16ReadPos;
		_u16 u16ReadLen = u16DataSize > p_u16BufferLen ? p_u16BufferLen : u16DataSize;
		memcpy(p_szData, pstCycleCache->pszCacheBuff + u16ReadPos, u16ReadLen);
		pstCycleCache->u16ReadPos = u16ReadPos + u16ReadLen;
		return u16ReadLen;
	}

	_u16 u16DataSize_cur = pstCycleCache->u16CacheSize + 1 - u16ReadPos;
	if (u16DataSize_cur > p_u16BufferLen)
	{
		_u16 u16ReadLen = p_u16BufferLen;
		memcpy(p_szData, pstCycleCache->pszCacheBuff + u16ReadPos, u16ReadLen);
		pstCycleCache->u16ReadPos = u16ReadPos + u16ReadLen;
		return u16ReadLen;
	}

	_u16 u16ReadLen = (p_u16BufferLen - u16DataSize_cur) >= u16WritePos ? u16WritePos : (p_u16BufferLen - u16DataSize_cur);
	memcpy(p_szData, pstCycleCache->pszCacheBuff + u16ReadPos, u16DataSize_cur);
	memcpy(p_szData + u16DataSize_cur, pstCycleCache->pszCacheBuff, u16ReadLen);
	pstCycleCache->u16ReadPos = u16ReadLen;
	return (u16DataSize_cur + u16ReadLen);
}

_INT CycleCache_pop(_INT p_hHandle, _CHAR *p_szData, const _u16 p_u16BufferLen)
{
	CHECK_NULL(p_hHandle, 0);
	CycleCache_s *pstCycleCache = (CycleCache_s *)p_hHandle;
	C_LOCK(pstCycleCache->bNeedLock, pstCycleCache->stLock);
	_INT nRet = CycleCache_pop_base(pstCycleCache, p_szData, p_u16BufferLen);
	C_UNLOCK(pstCycleCache->bNeedLock, pstCycleCache->stLock);
	return nRet;
}
