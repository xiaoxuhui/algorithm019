#include "SysLog.h"
#include "SysConfig.h"
#include "BaseFile.h"
#include <stdio.h>
#include <stdarg.h>
#include "SysPrint.h"
#include <string.h>
#include "SysTime.h"

#define MAX_LOG_CHAR	1024


_INT sys_log(const _CHAR* p_szFormat, ...)
{
	_INT nRet = 0;

	_CHAR buf[MAX_LOG_CHAR] = { 0 };
	_CHAR timeBuf[32] = { 0 };
	SysTime_s stSysTime = getCurSysTime();
	sprintf(timeBuf, "[%04d-%02d-%02d %02d:%02d:%02d] ", stSysTime.year, stSysTime.month, stSysTime.day, stSysTime.hour, stSysTime.minute, stSysTime.second);

	va_list args;
	va_start(args, p_szFormat);
	vsprintf(buf, p_szFormat, args);
	va_end(args);

	_PRINT_("%s%s", timeBuf, buf);

#if LOG_ON
	static File_s stFile;
	static _BOOL bInitFlg = false;
	if (!bInitFlg)
	{
		nRet = openFile(&stFile, LOG_FILE_PATH, ADD_WRITE);
		if (nRet != 0)
		{
			_PRINT_("open (%s) failed..\n", LOG_FILE_PATH);
			return -1;
		}
		bInitFlg = true;
	}

	if (!writeFile(&stFile, timeBuf, strlen(timeBuf)))
	{
		_PRINT_("write (%s) failed..\n", LOG_FILE_PATH);
	}

	if (!writeFile(&stFile, buf, strlen(buf)))
	{
		_PRINT_("write (%s) failed..\n", LOG_FILE_PATH);
	}
	flushFile(&stFile);
	//closeFile(&stFile);

#endif // LOG_ON
	return 0;
}

