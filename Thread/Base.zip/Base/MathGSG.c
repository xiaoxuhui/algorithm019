#include "MathGSG.h"
#include "GSG.h"

_USHORT GSG_getCheckSum(const _UCHAR* p_pData, _UINT p_nDataLen)
{
	_USHORT nCheckSum = 0;
	for (_UINT i = 0; i < p_nDataLen; ++i){
		nCheckSum += p_pData[i];
	}
	return nCheckSum;
}

#ifndef OS_LINUX_DRIVER

int GSG_abs(const int p_nA, const int p_nB)
{
	int nTemp = p_nA - p_nB;
	if (nTemp > 0)
		return nTemp;
	return -nTemp;
}

_INT GSG_sign(double x, double f)
{
	if (x > f)
		return 1;
	if (x < -f)
		return -1;
	return 0;
}

float GSG_fabs(const float p_nA, const float p_nB)
{
	float nTemp = p_nA - p_nB;
	if (nTemp > 0)
		return nTemp;
	return -nTemp;
}

#define _PI_DIV_180		0.01745329251994329576923690768489
#define _180_DIV_PI		57.295779513082320876798154814105
_FLOAT angle2radian(_FLOAT p_angle)
{
	//return (_FLOAT)(p_angle * _PI_DIV_180);
	return (_FLOAT)(p_angle * (_FLOAT)_PI / 180.f);
}

_FLOAT radian2angle(_FLOAT p_radian)
{
	//return (_FLOAT)(p_radian * _180_DIV_PI);
	return (_FLOAT)((p_radian * 180.f) / (_FLOAT)_PI);
}



static _CHAR g_szHexChar[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

_VOID GSG_toHexChar(const _u8 p_u8Value, _CHAR p_szHexChar[2])
{
	int nHigh = ((p_u8Value & 0xF0) >> 4);
	p_szHexChar[0] = g_szHexChar[nHigh];

	int nLow = (p_u8Value & 0x0F);
	p_szHexChar[1] = g_szHexChar[nLow];
}

_BOOL	GSG_Equal(const float p_fFirst, const float p_fSecond, const float p_fPricesion)
{
	if (fabs(p_fFirst - p_fSecond) > p_fPricesion)
	{
		return false;
	}
	return true;
}


//_u8 GSG_ConvertHexChar(_u8 ch)
//{
//	if ((ch >= '0') && (ch <= '9'))
//		return ch - 0x30;
//	else if ((ch >= 'A') && (ch <= 'F'))
//		return ch - 'A' + 10;
//	else if ((ch >= 'a') && (ch <= 'f'))
//		return ch - 'a' + 10;
//	else
//		return -1;
//}
_u8 GSG_parseHexChar_1(const _CHAR p_HexChar)
{
	switch (p_HexChar)
	{
	case '0':
		return 0;
	case '1':
		return 1;
	case '2':
		return 2;
	case '3':
		return 3;
	case '4':
		return 4;
	case '5':
		return 5;
	case '6':
		return 6;
	case '7':
		return 7;
	case '8':
		return 8;
	case '9':
		return 9;
	case 'A':
	case 'a':
		return 10;
	case 'B':
	case 'b':
		return 11;
	case 'C':
	case 'c':
		return 12;
	case 'D':
	case 'd':
		return 13;
	case 'E':
	case 'e':
		return 14;
	case 'F':
	case 'f':
		return 15;
	default:
		return 0;
	}
}

_u8 GSG_parseHexChar(const _CHAR p_szHexChar[2])
{
	_u8 nHigh = GSG_parseHexChar_1(p_szHexChar[0]);
	_u8 nLow = GSG_parseHexChar_1(p_szHexChar[1]);
	_u8 nValue = (nHigh << 4) | nLow;
	return nValue;
}


_u8  GSG_sliceNum(const _u8  p_u8TotalCount, const _u8 p_u8PerNum)
{
	 _u8	u8PacketCount = p_u8TotalCount / p_u8PerNum;
	 _u8	u8DeltaAreaNum = p_u8TotalCount%p_u8PerNum;
	 if (u8DeltaAreaNum == 0)
	 {
		  return  u8PacketCount;
	 }
	 else
	 {
		  return  (u8PacketCount + 1);
	 }
}

 _CHAR *GSG_u32toa(const _u32 p_u32Value, _CHAR *p_szData, _BOOL p_bIsHex)
 {
	 if (p_bIsHex)
	 {
		 _u8 *szMod = (_u8 *)(&p_u32Value);
		 _INT nOffset = 0;
		 _BOOL bIsFirstZero = true; // modify by xxh at 2017-11-18 ����Ǹ�λ��0�����Ե�����
		 for (int i = 3; i >= 0; i--)
		 {
			 if (szMod[i] == 0 && bIsFirstZero){
				 continue;
			 }
			 bIsFirstZero = false;
			 GSG_toHexChar(szMod[i], p_szData + nOffset);
			 nOffset += 2;
		 }
		 if (nOffset == 0){
			 p_szData[nOffset] = '0';
			 p_szData[nOffset + 1] = '0';
			 nOffset += 2;
		 }
		 p_szData[nOffset] = '\0';
		 return p_szData;
	 }

	 _u8 szMod[12] = { 0 };
	 _u32 nDiv = p_u32Value;
	 int nValidCount = 0;
	 for (; nValidCount < 12; nValidCount++)
	 {
		 szMod[nValidCount] = (_u8)(nDiv % 10);
		 nDiv /= 10;
		 if (nDiv == 0){
			 break;
		 }
	 }

	 _INT nOffset = 0;
	 for (; nValidCount >= 0; nValidCount--)
	 {
		 p_szData[nOffset] = '0' + szMod[nValidCount];
		 nOffset++;
	 }
	 p_szData[nOffset] = '\0';
	 return p_szData;
 }

 _CHAR *GSG_s32toa(const _s32 p_s32Value, _CHAR *p_szData, _BOOL p_bIsHex)
 {	 
	 if (p_bIsHex)
	 {
		 return GSG_u32toa(p_s32Value, p_szData, true);
	 }

	 if (p_s32Value < 0){
		 p_szData[0] = '-';
		 _u32 u32Value = (_u32)(-p_s32Value);
		 GSG_u32toa(u32Value, p_szData + 1, p_bIsHex);
		 return p_szData;
	 }

	 return GSG_u32toa(p_s32Value, p_szData, p_bIsHex);
 }

#define MILLION		1000000l

 _CHAR *GSG_ftoa(const _DOUBLE p_fValue, _CHAR *p_szData)
 {
	 _s32 s32Value = (_u32)(p_fValue * MILLION);
	 _s32 s32Int = s32Value / MILLION;
	 _u32 u32Float = abs(s32Value % MILLION);
	 GSG_s32toa(s32Int, p_szData, false);
	 _u32 nStrLen = strlen(p_szData);
	 p_szData[nStrLen] = '.';
	 _CHAR szFloat[7] = { 0 };	 
	 GSG_u32toa(u32Float, szFloat, false);
	 memset(p_szData + nStrLen + 1, '0', 6);
	 memcpy(p_szData + nStrLen + 7 - strlen(szFloat), szFloat, strlen(szFloat));
	 return p_szData;
 }


#endif
 _s32 GSG_div(_s32 p_s32A, _s32 p_s32B)
 {
	 DBG_ASSERT(p_s32B != 0);
	 if (p_s32A == 0){
		 return 0;
	 }

	 _u32 u32A = abs(p_s32A);
	 _u32 u32B = abs(p_s32B);

	 _s32 s32C = (u32A + u32B / 2) / u32B;

	 _s32 s32Sign_A = p_s32A > 0 ? 1 : -1;
	 _s32 s32Sign_B = p_s32B > 0 ? 1 : -1;
	 s32C = (s32Sign_A * s32Sign_B) > 0 ? s32C : -s32C;
	 return s32C;
 }
