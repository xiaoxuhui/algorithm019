#include "SegmentHist.h"
#include "GSG.h"
#include "MathGSG.h"

typedef struct _SegmentHist_s
{
	_s32				s32MinNum;
	_s32				s32MaxNum;
	_u32				u32SegmentNum;

	_u32				u32SegmentCount;
	_u32*				szHist;
	_s64				s64Sum;
	_u32				u32NumCount;
}SegmentHist_s;

_INT SegmentHist_create(const _s32 p_nMinNum, const _u32 p_u32SegmentNum, const _u32 p_u32SegmentCount)
{
	SegmentHist_s *pstSegmentHist = NULL;
	INIT_STATIC_PARAM(pstSegmentHist, SegmentHist_s, NULL);
	pstSegmentHist->s32MinNum = p_nMinNum;
	pstSegmentHist->s32MaxNum = p_nMinNum + p_u32SegmentCount * p_u32SegmentNum;
	pstSegmentHist->u32SegmentNum = p_u32SegmentNum;
	pstSegmentHist->u32SegmentCount = p_u32SegmentCount;
	pstSegmentHist->szHist = SYS_MALLOC(sizeof(_u32)* p_u32SegmentCount);
	DBG_ASSERT(pstSegmentHist->szHist != NULL);
	memset(pstSegmentHist->szHist, 0, sizeof(_u32) * p_u32SegmentCount);
//	_PRINT_LN("SH_create(%d,%u,%u,%d)", pstSegmentHist->s32MinNum, pstSegmentHist->u32SegmentNum, pstSegmentHist->u32SegmentCount, pstSegmentHist->s32MaxNum);
	return (_INT)pstSegmentHist;
}

_VOID SegmentHist_destroy(_INT p_hHandle)
{
	CHECK_NULL(p_hHandle);
	SegmentHist_s *pstSegmentHist = (SegmentHist_s *)p_hHandle;
	SYS_FREE(pstSegmentHist->szHist);
	SYS_FREE(pstSegmentHist);
}

_VOID SegmentHist_reset(_INT p_hHandle)
{
	SegmentHist_s *pstSegmentHist = (SegmentHist_s *)p_hHandle;
	memset(pstSegmentHist->szHist, 0, sizeof(_u32) * pstSegmentHist->u32SegmentCount);
	pstSegmentHist->u32NumCount = 0;
	pstSegmentHist->s64Sum = 0;
}

_VOID SegmentHist_push(_INT p_hHandle, _s32 p_s32Num)
{
	SegmentHist_s *pstSegmentHist = (SegmentHist_s *)p_hHandle;
	_s32 s32Num = p_s32Num;
	s32Num = MAX_NUM(s32Num, pstSegmentHist->s32MinNum);
	s32Num = MIN_NUM(s32Num, pstSegmentHist->s32MaxNum);

	_u32 u32Index = (s32Num - pstSegmentHist->s32MinNum) / pstSegmentHist->u32SegmentNum;
	u32Index = MIN_NUM(u32Index, pstSegmentHist->u32SegmentCount - 1);
	pstSegmentHist->szHist[u32Index]++;
	pstSegmentHist->s64Sum += p_s32Num;
	pstSegmentHist->u32NumCount++;
	//_PRINT_LN("SH_push:%d,%d,%u", p_s32Num, s32Num, u32Index);
}

_VOID SegmentHist_print(_INT p_hHandle, _CHAR *p_szTitle)
{
	SegmentHist_s *pstSegmentHist = (SegmentHist_s *)p_hHandle;	
	if (pstSegmentHist->u32NumCount == 0){
		pstSegmentHist->u32NumCount = 1;
	}
	_s32 s32Ave = (_s32)(pstSegmentHist->s64Sum / pstSegmentHist->u32NumCount);
	_B_PRINT_TIME();
	_PRINT_("hist_%s:ave(%d),tc(%d)", p_szTitle, s32Ave, pstSegmentHist->u32NumCount);
	for (size_t i = 0; i < pstSegmentHist->u32SegmentCount;i++)
	{
		_s32 s32Begin = pstSegmentHist->s32MinNum + i * pstSegmentHist->u32SegmentNum;
		if (pstSegmentHist->szHist[i] != 0){
			_PRINT_("[%d,%u]", s32Begin,pstSegmentHist->szHist[i]);
		}
	}
	_PRINT_LN("");
}

const _u32 *SegmentHist_getAll(_INT p_hHandle)
{
	SegmentHist_s *pstSegmentHist = (SegmentHist_s *)p_hHandle;
	return pstSegmentHist->szHist;
}

_u32 SegmentHist_getCount(_INT p_hHandle)
{
	SegmentHist_s *pstSegmentHist = (SegmentHist_s *)p_hHandle;
	return pstSegmentHist->u32NumCount;
}
