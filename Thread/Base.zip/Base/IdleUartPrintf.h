#ifndef _IDLE_UART_PRINTF_H_
#define _IDLE_UART_PRINTF_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "TypeDef.h"
  
typedef _VOID(*PrintCallBack)(const _CHAR *p_pszOutBuf, const _u16 p_u16BufLen);
_BOOL IUP_init(PrintCallBack p_function);
_VOID IUP_uninit(_VOID);
_VOID IUP_putString(const _CHAR* p_szMsg, const _u16 p_nLen);

_VOID uartPrintf_flush(_VOID);

_VOID IUP_takeString(_CHAR* p_szMsg, const _u16 p_BufferLen, _u16* p_nLen);

#ifdef __cplusplus
}
#endif

#endif // _IDLE_UART_PRINTF_H_
